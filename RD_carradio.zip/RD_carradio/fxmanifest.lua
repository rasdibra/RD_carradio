fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'RD Scripts'
description 'RD_carradio V5.2 - stable no-glitch car radio UI, natural vehicle exit, QB-Core/ESX support'
version '5.2.0'

shared_scripts { 'config.lua' }
client_scripts { 'client.lua' }
server_scripts { 'server.lua' }

ui_page 'html/controller.html'
files {
    'html/controller.html',
    'html/dui.html',
    'html/style.css',
    'html/controller.js',
    'html/dui.js',
    'html/assets/icons/home.svg',
    'html/assets/icons/music.svg',
    'html/assets/icons/maps.svg',
    'html/assets/icons/actions.svg',
    'html/assets/icons/status.svg',
    'html/assets/icons/contacts.svg',
    'html/assets/icons/camera.svg'
}

dependency 'xsound'
