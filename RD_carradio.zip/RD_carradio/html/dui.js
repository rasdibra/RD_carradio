const $ = (s, p = document) => p.querySelector(s);
const $$ = (s, p = document) => Array.from(p.querySelectorAll(s));
let state = {};
let currentPage = 'home';
let currentRadio = null;
let player = null;
let ytReady = false;
let ytFallbackActive = false;
let videoCinemaMode = false;
let mapZoom = 1.0;
let gpsTalkEnabled = false;
let mapStyle = 'dark';

function resourceName(){ return typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'RD_carradio'; }
function post(name, data = {}){ return fetch(`https://${resourceName()}/${name}`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data) }).catch(()=>{}); }
function esc(v){ return String(v == null ? '' : v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function refreshVideoMode(){ document.body.classList.remove('video-stream'); }
function setPage(page){
  currentPage = page || 'home';
  $$('.page').forEach(p => p.classList.toggle('active', p.dataset.view === currentPage));
  $$('.dock-app').forEach((b,i) => b.classList.toggle('active', (['home','music','maps','actions','status','camera'][i] || '') === currentPage));
  refreshVideoMode();
}
function updateText(id, value){ const el = $(id); if(el) el.textContent = value; }

function clampNum(v, min, max){ v = Number(v); if(!Number.isFinite(v)) v = min; return Math.max(min, Math.min(max, v)); }
function formatEta(seconds){
  seconds = Number(seconds || 0);
  if(!seconds || seconds < 0) return '--';
  const mins = Math.max(1, Math.ceil(seconds / 60));
  return `${mins} min`;
}
function stableRand(seed){
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}
function buildRoads(box, compact){
  if(!box) return;
  const coords = (state && state.coords) || { x: 0, y: 0 };
  const seed = Math.floor((coords.x || 0) / 70) * 31 + Math.floor((coords.y || 0) / 70) * 17;
  const roads = [];
  const count = compact ? 9 : 15;
  for(let i=0;i<count;i++){
    const r = stableRand(seed + i * 13.37);
    const x = (8 + stableRand(seed + i * 2.1) * 84).toFixed(2) + '%';
    const y = (8 + stableRand(seed + i * 3.7) * 84).toFixed(2) + '%';
    const rot = [0, 90, 28, -28, 12, -70][Math.floor(r * 6) % 6];
    const major = i % 5 === 0;
    const cls = major ? 'major' : (i % 3 === 0 ? 'street' : 'alley');
    const w = (major ? 78 + r * 44 : 38 + r * 50).toFixed(0) + '%';
    roads.push(`<i class="live-road ${cls}" style="--x:${x};--y:${y};--r:${rot}deg;--w:${w};--h:${major ? 16 : (cls === 'street' ? 9 : 5)}px"></i>`);
  }
  box.innerHTML = roads.join('');
}
function renderMapBlips(layer, compact){
  if(!layer) return;
  const blips = (state && state.map && Array.isArray(state.map.blips)) ? state.map.blips : [];
  const heading = Number((state && state.heading) || 0);
  const scale = compact ? 18 : 11;
  const maxRadius = compact ? 42 : 48;
  layer.innerHTML = blips.slice(0, compact ? 20 : 55).map(b => {
    const dx = Number(b.dx || 0), dy = Number(b.dy || 0);
    const dist = Math.sqrt(dx*dx + dy*dy) || 1;
    const bearing = Math.atan2(dx, dy) * 180 / Math.PI;
    const rel = ((bearing - heading + 540) % 360) - 180;
    const radius = Math.min(maxRadius, Math.max(5, (dist / scale) * mapZoom));
    const rad = rel * Math.PI / 180;
    const x = clampNum(50 + Math.sin(rad) * radius, 5, 95);
    const y = clampNum(50 - Math.cos(rad) * radius, 6, 94);
    const kind = b.kind === 'camera' ? 'camera' : (Number(b.sprite) === 60 || String(b.label || '').toLowerCase().includes('police') ? 'police' : 'server');
    return `<i class="map-blip ${kind}" style="left:${x.toFixed(1)}%;top:${y.toFixed(1)}%"><span>${kind === 'camera' ? '⌖' : kind === 'police' ? '★' : '•'}</span></i>`;
  }).join('');
}
function updateMapBox(map, roads, compact){
  if(!map) return;
  map.classList.toggle('dark-map', (mapStyle || (state.map && state.map.style) || 'dark') === 'dark');
  const heading = Number((state && state.heading) || 0);
  map.style.setProperty('--map-zoom', mapZoom.toFixed(2));
  map.style.setProperty('--map-rot', `${-heading}deg`);
  map.style.setProperty('--car-r', `${heading}deg`);
  const wp = state && state.waypoint;
  const active = !!(wp && wp.active);
  map.style.setProperty('--wp-visible', active ? '1' : '0');
  let rel = Number(wp && wp.relativeAngle || 0);
  let dist = Number(wp && wp.distanceKm || 0) * 1000;
  let radius = active ? Math.min(compact ? 34 : 42, Math.max(8, dist / (compact ? 18 : 13) * mapZoom)) : 0;
  const rad = rel * Math.PI / 180;
  const x = 50 + Math.sin(rad) * radius;
  const y = 50 - Math.cos(rad) * radius;
  map.style.setProperty('--wp-left', `${clampNum(x, 8, 92).toFixed(1)}%`);
  map.style.setProperty('--wp-top', `${clampNum(y, 10, 88).toFixed(1)}%`);
  map.style.setProperty('--route-visible', active ? '.95' : '0');
  map.style.setProperty('--route-h', `${Math.min(compact ? 95 : 180, Math.max(16, radius * (compact ? 2.0 : 3.0))).toFixed(0)}px`);
  map.style.setProperty('--route-r', `${rel}deg`);
  buildRoads(roads, compact);
  renderMapBlips(compact ? $('#mapBlipsHome') : $('#mapBlipsBig'), compact);
}
function renderLiveMaps(){
  updateMapBox($('#liveMapHome'), $('#mapRoadsHome'), true);
  updateMapBox($('#liveMapBig'), $('#mapRoadsBig'), false);
  const wp = state && state.waypoint;
  updateText('#mapZoomLabel', `${mapZoom.toFixed(1)}x`);
  updateText('#mapCompass', state.headingLabel || 'N');
  updateText('#miniMapEta', wp && wp.active ? `${formatEta(wp.etaSeconds)} ETA` : 'Live GPS');
  const route = document.querySelector('.route-card');
  if(route){
    let badge = route.querySelector('.arrive-badge');
    if(wp && wp.active && Number(wp.distanceKm || 0) < 0.05){
      if(!badge){ badge = document.createElement('div'); badge.className='arrive-badge'; route.appendChild(badge); }
      badge.textContent = 'Arriving soon';
    } else if(badge) badge.remove();
  }
}
function setMapZoom(v){
  mapZoom = clampNum(v, 0.6, 2.4);
  localStorage.setItem('rd_carradio_mapzoom', mapZoom.toFixed(2));
  renderLiveMaps();
}
function updateGpsTalkUI(){
  const btn = $('#gpsTalkBtn');
  const hint = $('#gpsTalkHint');
  if(!btn) return;
  btn.classList.toggle('on', !!gpsTalkEnabled);
  btn.classList.toggle('off', !gpsTalkEnabled);
  btn.textContent = gpsTalkEnabled ? 'GPS Talk ON' : 'GPS Talk OFF';
  if(hint) hint.textContent = gpsTalkEnabled ? 'Voice enabled' : 'Voice disabled';
}
function updateTrafficUI(){
  const pill = $('#trafficPill');
  if(!pill) return;
  const tl = state && state.trafficLight;
  pill.classList.remove('red','green','yellow','off');
  if(!tl || !tl.active){ pill.classList.add('off'); pill.querySelector('b').textContent = 'No traffic light'; pill.querySelector('span').textContent = 'Live road sensor'; return; }
  pill.classList.add(tl.state || 'off');
  pill.querySelector('b').textContent = `${String(tl.state || 'light').toUpperCase()} light`;
  pill.querySelector('span').textContent = `${tl.distanceText || tl.distance + ' m'} ahead`;
}
function updateSensorUI(sensor){
  const box = $('#sensorBox');
  if(!box) return;
  sensor = sensor || {};
  const level = Number(sensor.level || 0);
  box.dataset.level = String(level);
  updateText('#sensorDistance', sensor.hit ? (sensor.distanceText || `${Number(sensor.distance || 0).toFixed(1)} m`) : '--');
  const side = sensor.side && sensor.side !== 'none' ? ` ${String(sensor.side).toUpperCase()}` : '';
  updateText('#sensorText', sensor.hit ? (level >= 4 ? `STOP${side} - object very close` : level >= 3 ? `Object close${side}` : `Object behind${side}`) : 'Parking sensor clear');
  $$('.sensor-bars i', box).forEach((bar, idx) => bar.classList.toggle('on', idx < level));
}
function playSensorBeep(distance=2.0, volume=.22){
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    const d = Number(distance || 2);
    o.type = 'square'; o.frequency.value = d < .6 ? 1180 : d < 1.4 ? 980 : 760; g.gain.value = clampNum(volume, 0.01, .35);
    o.connect(g); g.connect(ctx.destination); o.start(); g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + .08);
    setTimeout(()=>{ try{o.stop();ctx.close();}catch(e){} }, 95);
  }catch(e){}
}
function chooseVoice(gender, lang){
  try{
    const voices = window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
    const wanted = String(gender || 'female').toLowerCase();
    const sameLang = voices.filter(v => (v.lang || '').toLowerCase().startsWith(String(lang || 'en').slice(0,2).toLowerCase()));
    const pool = sameLang.length ? sameLang : voices;
    const femaleWords = ['female','woman','samantha','susan','victoria','karen','moira','tessa'];
    const maleWords = ['male','man','daniel','alex','david','fred','george'];
    const words = wanted === 'male' ? maleWords : femaleWords;
    return pool.find(v => words.some(w => String(v.name || '').toLowerCase().includes(w))) || pool[0] || null;
  }catch(e){ return null; }
}
function speakText(text, lang='en-US', volume=.85, gender='female'){
  try{
    if(window.speechSynthesis){
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang; u.volume = clampNum(volume, 0, 1); u.rate = gender === 'male' ? .92 : .96; u.pitch = gender === 'male' ? .82 : 1.08;
      const v = chooseVoice(gender, lang); if(v) u.voice = v;
      window.speechSynthesis.speak(u);
      return;
    }
  }catch(e){}
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.type = 'sine'; o.frequency.value = gender === 'male' ? 540 : 880; g.gain.value = .08;
    o.connect(g); g.connect(ctx.destination); o.start(); setTimeout(()=>{o.stop();ctx.close();}, 220);
  }catch(e){}
}


function updateState(s){
  state = s || state;
  if(!state) return;
  const ui = state.ui || {};
  updateText('#serverNameBanner', ui.serverName || 'EAGLE CITY RP');
  updateText('#serverNameSub', ui.musicBannerText || 'Audio-only mode • xSound stable audio');
  $$('[data-time]').forEach(e => e.textContent = state.time || '00:00');
  updateText('#vehicleName', state.model || 'Vehicle');
  updateText('#statusVehicleLabel', `${state.model || 'Vehicle'} · ${state.plate || 'RD'}`);
  mapStyle = (state.map && state.map.style) || mapStyle || 'dark';
  updateText('#vehiclePlate', state.plate || 'RD');
  updateText('#streetName', state.street || 'Street');
  updateText('#weatherName', state.weather || 'Weather');
  updateText('#speedText', state.speedText || state.speed || 0);
  updateText('#fuelText', `${Math.round(state.fuel || 0)}%`);
  updateText('#weatherCard', state.weather || 'Live');
  updateText('#mapStreetHome', state.street || 'Street');
  updateText('#mapStreet', state.street || 'Street');
  updateText('#mapZone', state.zone || 'Zone');
  updateText('#navHeading', state.headingLabel || 'N');
  updateText('#navSpeed', `${state.speed || 0} km/h`);
  if(state.waypoint && state.waypoint.active){
    const eta = formatEta(state.waypoint.etaSeconds);
    updateText('#wpDistance', state.waypoint.distanceText || 'Waypoint');
    updateText('#navTitle', 'Navigate to waypoint');
    updateText('#navDetails', `${state.street || 'Current road'} → ${state.waypoint.waypointStreet || 'waypoint'} · ${eta}`);
    updateText('#navDistance', state.waypoint.distanceText || '0 km');
    updateText('#navSpeed', `${state.waypoint.avgSpeed || state.speed || 0} km/h`);
  } else {
    updateText('#wpDistance', 'No waypoint');
    updateText('#navTitle', 'No waypoint set');
    updateText('#navDetails', 'Set waypoint in GTA map.');
    updateText('#navDistance', '0 km');
  }
  gpsTalkEnabled = !!(state.navigation && state.navigation.gpsTalk);
  updateGpsTalkUI();
  updateTrafficUI();
  if(state.controls) updateText('#lockDot', state.controls.locked ? '🔒' : '🔓');
  if(state.health){
    updateText('#engineTemp', `${state.health.engineTemp || 0}°`);
    updateText('#oilLevel', `${state.health.oil || 0}%`);
    updateText('#tankHealth', `${state.health.fuelTank || 0}%`);
    updateText('#bodyHealth', `${state.health.body || 0}%`);
    updateText('#tyreBurst', state.health.tyres || 'NO');
    updateText('#dirtLevel', `${state.health.dirt || 0}%`);
  }
  renderLiveMaps();
  if(state.radio) {
    updateRadio(state.radio, false);
  } else if(state.inVehicle && currentRadio) {
    currentRadio = null;
    updateText('#radioTitleHome','No music');
    updateText('#radioSubHome','Ready');
    updateText('#radioTitle','No music');
    updateText('#radioChannel','RD CarRadio');
    renderQueue([]);
    refreshVideoMode();
  }
}
function renderQueue(queue){
  const box = $('#queueList');
  if(!box) return;
  const q = Array.isArray(queue) ? queue : [];
  if(!q.length){ box.innerHTML = '<div class="queue-item"><div></div><div><b>Queue empty</b><span>Auto next enabled</span></div><span>▶</span></div>'; return; }
  box.innerHTML = '';
  q.slice(0, 10).forEach(r => {
    const el = document.createElement('div');
    el.className = 'queue-item';
    el.innerHTML = `<img src="${esc(r.thumb || '')}"><div><b>${esc(r.title || 'YouTube Music')}</b><span>${esc(r.channel || 'YouTube')}</span></div><span>▶</span>`;
    box.appendChild(el);
  });
}
function updateRadio(r, jumpMusic = true){
  if(arguments.length) currentRadio = r;
  if(!currentRadio) return;
  updateText('#radioTitleHome', currentRadio.title || 'Music');
  updateText('#radioSubHome', currentRadio.channel || 'YouTube');
  updateText('#radioTitle', currentRadio.title || 'YouTube Music');
  updateText('#radioChannel', currentRadio.channel || 'RD CarRadio');
  renderQueue(currentRadio.queue || []);
  if(jumpMusic) setPage('music');
  refreshVideoMode();
  
}
function youtubeEmbedUrl(id){ return ''; }
function fallbackVideo(videoId){ return; }
function onYouTubeIframeAPIReady(){ ytReady = false; }
function playVideo(videoId){ return; }
function stopVideo(){ const host = $('#yt'); if(host) host.innerHTML = '♪'; }

window.addEventListener('message', e => {
  const d = e.data || {};
  if(d.action === 'state') updateState(d.state);
  if(d.action === 'radio') updateRadio(d.radio);
  if(d.action === 'radioStop'){ currentRadio = null; stopVideo(); updateText('#radioTitleHome','No music'); updateText('#radioSubHome','Ready'); updateText('#radioTitle','No music'); updateText('#radioChannel','RD CarRadio'); renderQueue([]); refreshVideoMode(); }
  if(d.action === 'setPage') setPage(d.page);
  if(d.action === 'physicalConfig'){ videoCinemaMode = d.videoCinemaMode !== false; mapStyle = d.mapStyle || mapStyle; refreshVideoMode(); }
  if(d.action === 'mapZoom'){ mapZoom = clampNum(d.zoom || mapZoom, 0.6, 2.4); renderLiveMaps(); }
  if(d.action === 'speak') speakText(d.text || 'You have arrived at your waypoint.', d.lang || 'en-US', (d.volume !== undefined ? d.volume : .85), d.gender || (state.navigation && state.navigation.voiceGender) || 'female');
  if(d.action === 'cameraState'){ if(d.state) updateState(d.state); updateSensorUI(d.sensor); }
  if(d.action === 'sensorBeep') playSensorBeep(d.distance, d.volume);
  if(d.action === 'pause' && player) player.pauseVideo();
  if(d.action === 'resume' && player) player.playVideo();
});
setPage('home'); renderLiveMaps(); updateGpsTalkUI(); updateTrafficUI(); updateSensorUI({});
