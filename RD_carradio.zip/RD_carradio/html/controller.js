const $ = (s, p = document) => p.querySelector(s);
const $$ = (s, p = document) => Array.from(p.querySelectorAll(s));
let state = {};
let currentPage = 'home';
let lastResults = [];
let currentRadio = null;
let healthLog = [];
let mapZoom = Number(localStorage.getItem('rd_carradio_mapzoom') || 1.0);
let gpsTalkEnabled = false;
let contacts = [];
let selectedContact = null;
let tabletCfg = { Draggable: true, SavePosition: true };
let mapStyle = 'dark';

function resourceName(){ return typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'RD_carradio'; }
function post(name, data = {}){
  return fetch(`https://${resourceName()}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(data)
  }).catch(() => {});
}
function esc(v){ return String(v == null ? '' : v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function toast(msg){ const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add('hidden'), 2500); }
function savedSongs(){ try { return JSON.parse(localStorage.getItem('rd_carradio_saved') || '[]'); } catch { return []; } }
function setSavedSongs(items){ localStorage.setItem('rd_carradio_saved', JSON.stringify(items.slice(0, 16))); }

function extractYouTubeId(value){
  const v = String(value || '').trim();
  const patterns = [ /youtu\.be\/([\w-]{8,})/i, /youtube\.com\/watch\?.*?v=([\w-]{8,})/i, /music\.youtube\.com\/watch\?.*?v=([\w-]{8,})/i, /youtube\.com\/shorts\/([\w-]{8,})/i, /youtube\.com\/embed\/([\w-]{8,})/i, /^([\w-]{8,})$/i ];
  for(const p of patterns){ const m = v.match(p); if(m) return m[1]; }
  return '';
}
function youtubeThumb(id){ return id ? `https://img.youtube.com/vi/${id}/mqdefault.jpg` : ''; }
function youtubeEmbedUrl(id, muted = true){
  if(!id) return '';
  const params = new URLSearchParams({ autoplay:'1', controls:'1', rel:'0', modestbranding:'1', playsinline:'1', enablejsapi:'1' });
  if(muted) params.set('mute','1');
  return `https://www.youtube.com/embed/${encodeURIComponent(id)}?${params.toString()}`;
}
function cleanVideoTitle(track){
  if(track && track.title && track.title !== 'Manual YouTube Track') return track.title;
  const id = extractYouTubeId((track && (track.url || track.videoId)) || '');
  return id ? `YouTube video ${id}` : 'Manual YouTube Track';
}

function setPage(page, send = true){
  currentPage = page || 'home';
  $$('.page').forEach(p => p.classList.toggle('active', p.dataset.view === currentPage));
  $$('.dock-app[data-page]').forEach(b => b.classList.toggle('active', b.dataset.page === currentPage));
  if(send) post('page', { page: currentPage });
}

function updateText(id, value){ const el = $(id); if(el) el.textContent = value; }

function clampNum(v, min, max){ v = Number(v); if(!Number.isFinite(v)) v = min; return Math.max(min, Math.min(max, v)); }
function formatEta(seconds){
  seconds = Number(seconds || 0);
  if(!seconds || seconds < 0) return '--';
  const mins = Math.max(1, Math.ceil(seconds / 60));
  return `${mins} min`;
}
function stableRand(seed){
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}
function buildRoads(box, compact){
  if(!box) return;
  const coords = (state && state.coords) || { x: 0, y: 0 };
  const seed = Math.floor((coords.x || 0) / 70) * 31 + Math.floor((coords.y || 0) / 70) * 17;
  const roads = [];
  const count = compact ? 9 : 15;
  for(let i=0;i<count;i++){
    const r = stableRand(seed + i * 13.37);
    const x = (8 + stableRand(seed + i * 2.1) * 84).toFixed(2) + '%';
    const y = (8 + stableRand(seed + i * 3.7) * 84).toFixed(2) + '%';
    const rot = [0, 90, 28, -28, 12, -70][Math.floor(r * 6) % 6];
    const major = i % 5 === 0;
    const cls = major ? 'major' : (i % 3 === 0 ? 'street' : 'alley');
    const w = (major ? 78 + r * 44 : 38 + r * 50).toFixed(0) + '%';
    roads.push(`<i class="live-road ${cls}" style="--x:${x};--y:${y};--r:${rot}deg;--w:${w};--h:${major ? 16 : (cls === 'street' ? 9 : 5)}px"></i>`);
  }
  box.innerHTML = roads.join('');
}
function renderMapBlips(layer, compact){
  if(!layer) return;
  const blips = (state && state.map && Array.isArray(state.map.blips)) ? state.map.blips : [];
  const heading = Number((state && state.heading) || 0);
  const scale = compact ? 18 : 11;
  const maxRadius = compact ? 42 : 48;
  layer.innerHTML = blips.slice(0, compact ? 20 : 55).map(b => {
    const dx = Number(b.dx || 0), dy = Number(b.dy || 0);
    const dist = Math.sqrt(dx*dx + dy*dy) || 1;
    let bearing = Math.atan2(dx, dy) * 180 / Math.PI;
    let rel = ((bearing - heading + 540) % 360) - 180;
    let radius = Math.min(maxRadius, Math.max(5, (dist / scale) * mapZoom));
    const rad = rel * Math.PI / 180;
    const x = clampNum(50 + Math.sin(rad) * radius, 5, 95);
    const y = clampNum(50 - Math.cos(rad) * radius, 6, 94);
    const kind = b.kind === 'camera' ? 'camera' : (Number(b.sprite) === 60 || String(b.label || '').toLowerCase().includes('police') ? 'police' : 'server');
    const label = esc(b.label || kind);
    return `<i class="map-blip ${kind}" title="${label}" style="left:${x.toFixed(1)}%;top:${y.toFixed(1)}%"><span>${kind === 'camera' ? '⌖' : kind === 'police' ? '★' : '•'}</span></i>`;
  }).join('');
}
function updateMapBox(map, roads, compact){
  if(!map) return;
  map.classList.toggle('dark-map', (mapStyle || (state.map && state.map.style) || 'dark') === 'dark');
  const heading = Number((state && state.heading) || 0);
  map.style.setProperty('--map-zoom', mapZoom.toFixed(2));
  map.style.setProperty('--map-rot', `${-heading}deg`);
  map.style.setProperty('--car-r', `${heading}deg`);
  const wp = state && state.waypoint;
  const active = !!(wp && wp.active);
  map.style.setProperty('--wp-visible', active ? '1' : '0');
  let rel = Number(wp && wp.relativeAngle || 0);
  let dist = Number(wp && wp.distanceKm || 0) * 1000;
  let radius = active ? Math.min(compact ? 34 : 42, Math.max(8, dist / (compact ? 18 : 13) * mapZoom)) : 0;
  const rad = rel * Math.PI / 180;
  const x = 50 + Math.sin(rad) * radius;
  const y = 50 - Math.cos(rad) * radius;
  map.style.setProperty('--wp-left', `${clampNum(x, 8, 92).toFixed(1)}%`);
  map.style.setProperty('--wp-top', `${clampNum(y, 10, 88).toFixed(1)}%`);
  map.style.setProperty('--route-visible', active ? '.95' : '0');
  map.style.setProperty('--route-h', `${Math.min(compact ? 95 : 180, Math.max(16, radius * (compact ? 2.0 : 3.0))).toFixed(0)}px`);
  map.style.setProperty('--route-r', `${rel}deg`);
  buildRoads(roads, compact);
  renderMapBlips(compact ? $('#mapBlipsHome') : $('#mapBlipsBig'), compact);
}
function renderLiveMaps(){
  updateMapBox($('#liveMapHome'), $('#mapRoadsHome'), true);
  updateMapBox($('#liveMapBig'), $('#mapRoadsBig'), false);
  const wp = state && state.waypoint;
  updateText('#mapZoomLabel', `${mapZoom.toFixed(1)}x`);
  updateText('#mapCompass', state.headingLabel || 'N');
  updateText('#miniMapEta', wp && wp.active ? `${formatEta(wp.etaSeconds)} ETA` : 'Live GPS');
  const route = document.querySelector('.route-card');
  if(route){
    let badge = route.querySelector('.arrive-badge');
    if(wp && wp.active && Number(wp.distanceKm || 0) < 0.05){
      if(!badge){ badge = document.createElement('div'); badge.className='arrive-badge'; route.appendChild(badge); }
      badge.textContent = 'Arriving soon';
    } else if(badge) badge.remove();
  }
}
function setMapZoom(v){
  mapZoom = clampNum(v, 0.6, 2.4);
  localStorage.setItem('rd_carradio_mapzoom', mapZoom.toFixed(2));
  renderLiveMaps();
  post('mapZoom', { zoom: mapZoom });
}
function updateGpsTalkUI(){
  const btn = $('#gpsTalkBtn');
  const hint = $('#gpsTalkHint');
  if(!btn) return;
  btn.classList.toggle('on', !!gpsTalkEnabled);
  btn.classList.toggle('off', !gpsTalkEnabled);
  btn.textContent = gpsTalkEnabled ? 'GPS Talk ON' : 'GPS Talk OFF';
  if(hint) hint.textContent = gpsTalkEnabled ? 'Turn, speed and traffic voice enabled' : 'Voice guidance disabled';
  const sel = $('#voiceGender'); if(sel && state.navigation && state.navigation.voiceGender) sel.value = state.navigation.voiceGender;
}
function updateTrafficUI(){
  const pill = $('#trafficPill');
  if(!pill) return;
  const tl = state && state.trafficLight;
  pill.classList.remove('red','green','yellow','off');
  if(!tl || !tl.active){
    pill.classList.add('off');
    pill.querySelector('b').textContent = 'No traffic light';
    pill.querySelector('span').textContent = 'Live road sensor';
    return;
  }
  pill.classList.add(tl.state || 'off');
  pill.querySelector('b').textContent = `${String(tl.state || 'light').toUpperCase()} light`;
  pill.querySelector('span').textContent = `${tl.distanceText || tl.distance + ' m'} ahead`;
}
function updateSensorUI(sensor){
  const box = $('#sensorBox');
  if(!box) return;
  sensor = sensor || {};
  const level = Number(sensor.level || 0);
  box.dataset.level = String(level);
  updateText('#sensorDistance', sensor.hit ? (sensor.distanceText || `${Number(sensor.distance || 0).toFixed(1)} m`) : '--');
  const side = sensor.side && sensor.side !== 'none' ? ` ${String(sensor.side).toUpperCase()}` : '';
  updateText('#sensorText', sensor.hit ? (level >= 4 ? `STOP${side} - object very close` : level >= 3 ? `Object close${side}` : `Object behind${side}`) : 'Parking sensor clear');
  $$('.sensor-bars i', box).forEach((bar, idx) => bar.classList.toggle('on', idx < level));
}
function playSensorBeep(distance=2.0, volume=.42){
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    const d = Number(distance || 2);
    o.type = 'square';
    o.frequency.value = d < .6 ? 1180 : d < 1.4 ? 980 : 760;
    g.gain.value = clampNum(volume, 0.02, .7);
    o.connect(g); g.connect(ctx.destination); o.start();
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + .08);
    setTimeout(()=>{ try{o.stop();ctx.close();}catch(e){} }, 95);
  }catch(e){}
}
function chooseVoice(gender, lang){
  try{
    const voices = window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
    const wanted = String(gender || 'female').toLowerCase();
    const sameLang = voices.filter(v => (v.lang || '').toLowerCase().startsWith(String(lang || 'en').slice(0,2).toLowerCase()));
    const pool = sameLang.length ? sameLang : voices;
    const femaleWords = ['female','woman','zira','samantha','susan','victoria','karen','moira','tessa','google uk english female'];
    const maleWords = ['male','man','daniel','alex','david','fred','george','google uk english male'];
    const words = wanted === 'male' ? maleWords : femaleWords;
    return pool.find(v => words.some(w => String(v.name || '').toLowerCase().includes(w))) || pool[0] || null;
  }catch(e){ return null; }
}
function speakText(text, lang='en-US', volume=.85, gender='female'){
  try{
    if(window.speechSynthesis){
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang; u.volume = clampNum(volume, 0, 1); u.rate = gender === 'male' ? .92 : .96; u.pitch = gender === 'male' ? .82 : 1.08;
      const v = chooseVoice(gender, lang); if(v) u.voice = v;
      window.speechSynthesis.speak(u);
      return;
    }
  }catch(e){}
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(); const g = ctx.createGain();
    o.type = 'sine'; o.frequency.value = gender === 'male' ? 540 : 880; g.gain.value = .08;
    o.connect(g); g.connect(ctx.destination); o.start(); setTimeout(()=>{o.stop();ctx.close();}, 220);
  }catch(e){}
}


function updateState(s){
  state = s || state;
  if(!state) return;
  const ui = state.ui || {};
  updateText('#serverNameBanner', ui.serverName || 'EAGLE CITY RP');
  updateText('#serverNameSub', ui.musicBannerText || 'Audio-only mode • xSound stable audio');
  $$('[data-time]').forEach(e => e.textContent = state.time || '00:00');
  updateText('#vehicleName', state.model || 'Vehicle');
  updateText('#statusVehicleLabel', `${state.model || 'Vehicle'} · ${state.plate || 'RD'}`);
  mapStyle = (state.map && state.map.style) || mapStyle || 'dark';
  updateText('#vehiclePlate', state.plate || 'RD');
  updateText('#streetName', state.street || 'Street');
  updateText('#weatherName', state.weather || 'Weather');
  updateText('#speedText', state.speedText || state.speed || 0);
  updateText('#fuelText', `${Math.round(state.fuel || 0)}%`);
  updateText('#weatherCard', state.weather || 'Live');
  updateText('#mapStreetHome', state.street || 'Street');
  updateText('#mapStreet', state.street || 'Street');
  updateText('#mapZone', state.zone || 'Zone');
  updateText('#navHeading', state.headingLabel || 'N');
  updateText('#navSpeed', `${state.speed || 0} km/h`);
  if(state.waypoint && state.waypoint.active){
    const eta = formatEta(state.waypoint.etaSeconds);
    updateText('#wpDistance', state.waypoint.distanceText || 'Waypoint');
    updateText('#navTitle', 'Navigate to waypoint');
    updateText('#navDetails', `${state.street || 'Current road'} → ${state.waypoint.waypointStreet || 'waypoint'} · ${eta}`);
    updateText('#navDistance', state.waypoint.distanceText || '0 km');
    updateText('#navSpeed', `${state.waypoint.avgSpeed || state.speed || 0} km/h`);
  } else {
    updateText('#wpDistance', 'No waypoint');
    updateText('#navTitle', 'No waypoint set');
    updateText('#navDetails', 'Set waypoint in GTA map then open this app.');
    updateText('#navDistance', '0 km');
  }
  gpsTalkEnabled = !!(state.navigation && state.navigation.gpsTalk);
  updateGpsTalkUI();
  updateTrafficUI();
  if(state.controls){
    updateText('#lockDot', state.controls.locked ? '🔒' : '🔓');
  }
  if(state.health){
    updateText('#engineTemp', `${state.health.engineTemp || 0}°`);
    updateText('#oilLevel', `${state.health.oil || 0}%`);
    updateText('#tankHealth', `${state.health.fuelTank || 0}%`);
    updateText('#bodyHealth', `${state.health.body || 0}%`);
    updateText('#tyreBurst', state.health.tyres || 'NO');
    updateText('#dirtLevel', `${state.health.dirt || 0}%`);
    addHealthLog(state.health);
  }
  renderLiveMaps();
  updateRadio(state.radio || currentRadio);
  renderQueue((currentRadio && currentRadio.queue) || []);
}

let lastHealthKey = '';
function addHealthLog(h){
  const key = `${h.engineTemp}|${h.oil}|${h.body}|${h.dirt}|${h.tyres}`;
  if(key === lastHealthKey) return;
  lastHealthKey = key;
  const time = state.time || '00:00';
  healthLog.unshift(`<p><span>${esc(time)}</span>Engine ${esc(h.engineTemp)}° | Oil ${esc(h.oil)}% | Body ${esc(h.body)}% | Dirt ${esc(h.dirt)}%</p>`);
  healthLog = healthLog.slice(0, 18);
  const box = $('#statusLog');
  if(box) box.innerHTML = healthLog.join('');
}

function updateControllerVideo(r){
  const box = $('#controllerVideoBox');
  const frame = $('#controllerYt');
  if(box) box.classList.add('hidden');
  if(frame && frame.src) frame.src = 'about:blank';
}

function updateRadio(r){
  if(arguments.length) currentRadio = r;
  const title = (currentRadio && currentRadio.title) || 'No music';
  const channel = (currentRadio && currentRadio.channel) || (currentRadio ? 'YouTube / RD CarRadio' : 'Ready');
  updateText('#radioTitleHome', title);
  updateText('#radioSubHome', channel);
  updateText('#radioTitle', title === 'No music' ? 'No music playing' : title);
  updateText('#radioChannel', channel);
  const cover = $('#coverBox');
  if(cover){
    if(currentRadio && currentRadio.thumb){ cover.innerHTML = `<img src="${esc(currentRadio.thumb)}">`; }
    else cover.textContent = '♪';
  }
  updateControllerVideo(currentRadio);
  renderQueue((currentRadio && currentRadio.queue) || []);
}

function renderResults(results){
  lastResults = Array.isArray(results) ? results : [];
  const box = $('#results');
  if(!box) return;
  box.innerHTML = lastResults.length ? '' : '<div class="result"><div><b>No results</b><span>Use API key or paste YouTube link.</span></div></div>';
  lastResults.forEach((r, i) => {
    const el = document.createElement('div');
    el.className = 'result';
    el.innerHTML = `<img src="${esc(r.thumb || '')}"><div><b>${esc(r.title)}</b><span>${esc(r.channel || 'YouTube')}</span></div>`;
    el.onclick = () => playTrack(r, lastResults.slice(i + 1));
    box.appendChild(el);
  });
}

function renderSaved(){
  const box = $('#savedSongs');
  if(!box) return;
  const items = savedSongs();
  if(!items.length){
    box.innerHTML = '<div class="song-card"><b style="padding:16px">Saved songs</b><span>Press ♥ after playing.</span></div>';
    return;
  }
  box.innerHTML = '';
  items.slice(0, 8).forEach((r, i) => {
    const el = document.createElement('div');
    el.className = 'song-card';
    el.innerHTML = `<img src="${esc(r.thumb || '')}"><b>${esc(r.title)}</b><span>${esc(r.channel || 'Saved')}</span>`;
    el.onclick = () => playTrack(r, items.slice(i + 1));
    box.appendChild(el);
  });
}

function renderQueue(queue){
  const box = $('#queueList');
  if(!box) return;
  const q = Array.isArray(queue) ? queue : [];
  if(!q.length){ box.innerHTML = '<div class="queue-item"><div></div><div><b>Queue empty</b><span>Auto-next works after search.</span></div><span>▶</span></div>'; return; }
  box.innerHTML = '';
  q.slice(0, 12).forEach(r => {
    const el = document.createElement('div');
    el.className = 'queue-item';
    el.innerHTML = `<img src="${esc(r.thumb || '')}"><div><b>${esc(r.title || 'YouTube Music')}</b><span>${esc(r.channel || 'YouTube')}</span></div><span>▶</span>`;
    box.appendChild(el);
  });
}

function playTrack(track, queue = []){
  const volEl = $('#volume');
  const vol = Number((volEl && volEl.value) || 0.55);
  const id = track.videoId || extractYouTubeId(track.url);
  const thumb = track.thumb || youtubeThumb(id);
  const title = cleanVideoTitle(Object.assign({}, track, { videoId:id }));
  post('play', { videoId: id, url: track.url, title, channel: track.channel || 'YouTube', thumb, volume: vol, queue });
  currentRadio = Object.assign({}, track, { videoId:id, title, thumb, volume: vol, queue: queue });
  updateRadio(currentRadio);
  setPage('music');
}

function renderContacts(){
  const box = $('#contactsGrid');
  if(!box) return;
  const list = Array.isArray(contacts) ? contacts : [];
  if(!list.length){
    box.innerHTML = '<div class="contact-card offline"><div class="avatar service-avatar">••</div><b>No service online</b><span>Police / EMS / Mechanic not online</span><small>Auto refresh</small></div>';
    return;
  }
  const iconFor = (c) => {
    const key = String(c.icon || c.job || '').toLowerCase();
    if(key.includes('police')) return '<svg viewBox="0 0 64 64"><path d="M32 6l22 8v16c0 15-9 24-22 28C19 54 10 45 10 30V14l22-8z"/><path d="M22 29h20M32 19v20"/></svg>';
    if(key.includes('ambulance') || key.includes('doctor') || key.includes('ems')) return '<svg viewBox="0 0 64 64"><path d="M13 28h38v22H13z"/><path d="M21 28l6-12h14l6 12"/><path d="M32 22v20M22 32h20"/><circle cx="22" cy="52" r="4"/><circle cx="46" cy="52" r="4"/></svg>';
    if(key.includes('mechanic')) return '<svg viewBox="0 0 64 64"><path d="M43 10l11 11-10 10-11-11z"/><path d="M36 27L15 48l-5 6 6-5 21-21"/><path d="M18 15l10 10"/></svg>';
    return '<svg viewBox="0 0 64 64"><path d="M14 16h36v26H24L14 52z"/><path d="M22 25h20M22 33h14"/></svg>';
  };
  box.innerHTML = '';
  list.forEach(c => {
    const el = document.createElement('div');
    el.className = `contact-card ${c.available ? 'online' : 'offline'}`;
    el.innerHTML = `<div class="avatar service-avatar">${iconFor(c)}</div><b>${esc(c.name)}</b><span>${esc(c.phone || 'SMS')}</span><em>${Number(c.online || 0)} online</em><div class="contact-actions"><button data-sms>SMS + BLIP</button></div>`;
    el.querySelector('[data-sms]').onclick = (ev) => {
      ev.stopPropagation();
      selectedContact = c;
      updateText('#msgTo', c.name || 'Service');
      const body = $('#msgBody');
      if(body && !body.value.trim()) body.value = 'Need assistance at my GPS position.';
      post('contactAction', { action:'sms', name:c.name, job:c.job, phone:c.phone, message: body ? body.value : '' });
      toast(`SMS sent to ${c.name} with blip`);
    };
    el.onclick = () => { selectedContact = c; updateText('#msgTo', c.name || 'Service'); const body=$('#msgBody'); if(body && !body.value.trim()) body.value='Need assistance at my GPS position.'; };
    box.appendChild(el);
  });
}


function openCameraOverlay(s, sensor){
  document.body.classList.remove('closed');
  $('#carplay').style.display = 'none';
  $('#cameraOverlay').classList.remove('hidden');
  updateCamera(s || state, sensor);
}
function closeCameraOverlay(){
  $('#cameraOverlay').classList.add('hidden');
  $('#carplay').style.display = '';
  document.body.classList.add('closed');
}
function updateCamera(s, sensor){
  if(!s) return;
  updateText('#camStreet', s.street || 'Trunk parking camera');
  updateText('#camTime', s.time || '0:00');
  updateText('#camSpeed', s.speed || 0);
  updateText('#camDist', (s.waypoint && s.waypoint.distanceText) || '0 km');
  updateSensorUI(sensor);
}


function applyTabletPosition(){
  const frame = $('#carplay');
  if(!frame || !document.body.classList.contains('controller')) return;
  if(tabletCfg && tabletCfg.Draggable === false) return;
  const saved = localStorage.getItem('rd_carradio_tablet_pos');
  if(saved){
    try{ const p = JSON.parse(saved); frame.style.position='absolute'; frame.style.left=p.left; frame.style.top=p.top; frame.style.margin='0'; frame.style.transform='translate(-50%,-50%)'; }catch(e){}
  }
}
function enableTabletDrag(){
  const frame = $('#carplay'); const handle = $('.tablet-drag-handle');
  if(!frame || !handle || !document.body.classList.contains('controller')) return;
  let dragging=false, ox=0, oy=0;
  handle.addEventListener('mousedown', e => {
    if(tabletCfg && tabletCfg.Draggable === false) return;
    dragging=true; const r=frame.getBoundingClientRect(); ox=e.clientX-(r.left+r.width/2); oy=e.clientY-(r.top+r.height/2);
    frame.style.position='absolute'; frame.style.margin='0'; frame.style.transform='translate(-50%,-50%)'; document.body.classList.add('dragging-tablet');
  });
  document.addEventListener('mousemove', e => {
    if(!dragging) return; const left=e.clientX-ox, top=e.clientY-oy;
    frame.style.left = `${clampNum(left, 80, window.innerWidth-80)}px`; frame.style.top = `${clampNum(top, 60, window.innerHeight-60)}px`;
  });
  document.addEventListener('mouseup', () => {
    if(!dragging) return; dragging=false; document.body.classList.remove('dragging-tablet');
    if(!tabletCfg || tabletCfg.SavePosition !== false) localStorage.setItem('rd_carradio_tablet_pos', JSON.stringify({ left: frame.style.left, top: frame.style.top }));
  });
}
window.addEventListener('message', e => {
  const d = e.data || {};
  if(d.action === 'open'){
    tabletCfg = d.tablet || tabletCfg; mapStyle = d.mapStyle || mapStyle; applyTabletPosition(); post('requestContacts');
    document.body.classList.remove('closed');
    $('#carplay').style.display = '';
    $('#cameraOverlay').classList.add('hidden');
    setPage(d.page || 'home', false);
    renderSaved(); renderContacts();
  }
  if(d.action === 'close') document.body.classList.add('closed');
  if(d.action === 'state') updateState(d.state);
  if(d.action === 'radio') updateRadio(d.radio);
  if(d.action === 'radioStop'){ currentRadio = null; updateRadio(null); }
  if(d.action === 'volume'){
    const vol = Number(d.volume || 0);
    const v = $('#volume'); if(v) v.value = vol;
    updateText('#volRead', `${Math.round(vol * 100)}%`);
  }
  if(d.action === 'searchResult'){
    renderResults(d.results || []);
    if(!d.ok) toast(d.message || 'Search failed');
    else setPage('music');
  }
  if(d.action === 'cameraOpen') openCameraOverlay(d.state, d.sensor);
  if(d.action === 'cameraState') updateCamera(d.state, d.sensor);
  if(d.action === 'cameraClose') closeCameraOverlay();
  if(d.action === 'speak') speakText(d.text || 'You have arrived at your waypoint.', d.lang || 'en-US', (d.volume !== undefined ? d.volume : .85), d.gender || (state.navigation && state.navigation.voiceGender) || 'female');
  if(d.action === 'mapZoom'){ mapZoom = clampNum(d.zoom || mapZoom, 0.6, 2.4); renderLiveMaps(); }
  if(d.action === 'sensorBeep') playSensorBeep(d.distance, d.volume);
  if(d.action === 'contactsUpdate'){ contacts = Array.isArray(d.contacts) ? d.contacts : []; renderContacts(); }
  if(d.action === 'navAlert') toast(d.text || 'Navigation alert');
});

$('#closeBtn').onclick = () => post('close');
$('#cameraBtn').onclick = () => post('camera');
$$('.dock-app[data-page]').forEach(btn => btn.onclick = () => setPage(btn.dataset.page));
$$('[data-page]').forEach(btn => { if(!btn.classList.contains('dock-app')) btn.addEventListener('click', () => setPage(btn.dataset.page)); });
$('#searchBtn').onclick = () => post('search', { query: $('#query').value });
$('#query').addEventListener('keydown', e => { if(e.key === 'Enter') post('search', { query: $('#query').value }); });
$('#playUrlBtn').onclick = () => {
  const url = $('#url').value.trim();
  if(!url) return toast('Paste YouTube link first');
  const id = extractYouTubeId(url); playTrack({ url, videoId:id, title: id ? `YouTube video ${id}` : 'Manual YouTube Track', channel: 'Manual link', thumb: youtubeThumb(id) }, lastResults);
};
$('#pauseBtn').onclick = () => post('pause');
$('#resumeBtn').onclick = () => post('resume');
$('#nextBtn').onclick = () => post('next');
$('#volume').oninput = () => {
  const vol = Number($('#volume').value);
  updateText('#volRead', `${Math.round(vol * 100)}%`);
  post('volume', { volume: vol });
};
$('#saveBtn').onclick = () => {
  if(!currentRadio || (!currentRadio.videoId && !currentRadio.url)) return toast('No song to save');
  const items = savedSongs().filter(x => (x.videoId || x.url) !== (currentRadio.videoId || currentRadio.url));
  items.unshift(currentRadio);
  setSavedSongs(items);
  renderSaved();
  toast('Song saved');
};
$('#cancelMsg').onclick = () => { $('#msgBody').value = ''; };
$('#sendMsg').onclick = () => {
  if(!selectedContact) return toast('Choose Police / EMS / Mechanic first');
  const body = $('#msgBody');
  post('contactAction', { action:'sms', name:selectedContact.name, job:selectedContact.job, phone:selectedContact.phone, message: body ? body.value : '' });
  toast(`SMS sent to ${selectedContact.name} with blip`);
};
$$('[data-volume-step]').forEach(b => b.onclick = () => {
  const v = $('#volume');
  v.value = Math.max(0, Math.min(1, Number(v.value) + Number(b.dataset.volumeStep))).toFixed(2);
  v.dispatchEvent(new Event('input'));
});
$$('[data-action]').forEach(btn => btn.addEventListener('click', () => post('vehicleAction', { action: btn.dataset.action, value: btn.dataset.value })));
const zin = $('#mapZoomIn'); if(zin) zin.onclick = () => setMapZoom(mapZoom + 0.2);
const zout = $('#mapZoomOut'); if(zout) zout.onclick = () => setMapZoom(mapZoom - 0.2);
const gpsBtn = $('#gpsTalkBtn'); if(gpsBtn) gpsBtn.onclick = () => { gpsTalkEnabled = !gpsTalkEnabled; updateGpsTalkUI(); post('gpsTalk', { enabled: gpsTalkEnabled }); };
const voiceSel = $('#voiceGender'); if(voiceSel) voiceSel.onchange = () => post('gpsVoice', { gender: voiceSel.value });
document.addEventListener('keydown', e => {
  const code = String(e.code || '');
  const key = String(e.key || '').toLowerCase();
  if(code === 'KeyF' || key === 'f'){
    e.preventDefault();
    post('forceExit');
    return;
  }
  if(e.key === 'Escape' || e.key === 'Backspace'){
    e.preventDefault();
    post('close');
  }
});
renderSaved(); renderContacts(); renderQueue([]); renderLiveMaps(); updateGpsTalkUI(); updateTrafficUI(); updateSensorUI({}); enableTabletDrag();
