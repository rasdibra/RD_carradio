Config = {}

-- RD_carradio V5.2 - standalone / QB-Core / ESX vehicle infotainment
Config.Framework = 'auto' -- auto / qb / esx / standalone
Config.Command = 'carradio'
Config.Keybind = 'F6'
Config.RequireInsideVehicleToOpen = true
Config.DriverOnly = false
Config.Debug = false

-- Emri i serverit qe shfaqet ne Music app/banner ne tablet.
-- Ndryshoje ketu, p.sh. 'EAGLE CITY RP'.
Config.ServerName = 'EAGLE CITY RP'
Config.ServerSubtitle = 'Audio-only mode • music plays clean through xSound'

-- Safe exit fix: UI/camera/lock nuk duhet ta bllokoje lojtarin brenda makines.
Config.SafeExitAutoUnlock = true
Config.SafeExitNeverTrapPlayer = true -- mos e lejo lock-un e tabletit te te mbaje brenda makines
Config.SafeExitTeleportFallback = false -- V5.2 default OFF: mos e teleport/warp lojtarin kur del nga makina
Config.SafeExitInstantWarp = false -- V5.2 default OFF: dalje natyrale me animacion dere
Config.SafeExitRetryMs = 1800 -- nese lock/script e mban brenda, provon prape TaskLeaveVehicle pas kaq ms
Config.SafeExitFallbackDelayMs = 5200 -- teleport fallback vetem nese SafeExitTeleportFallback=true
Config.SafeExitRelockAfterMs = 1800 -- nese makina ishte locked, e hap per te dale dhe e mbyll prape pas daljes

-- V5.1 HARD FIX: kur luan muzike mos e le NUI/browser-in te mbaje fokusin dhe mos te bllokoje F/Exit.
Config.AutoCloseUIOnMusicPlay = true
Config.HardReleaseInputOnMusicPlay = false -- V5.2: nuk perdor me hard control loop qe e bente daljen keq
Config.AlwaysSafeExitMonitor = false -- V5.2: kur UI eshte mbyllur, F e le GTA/qb-core ta beje normal
Config.HardReleaseInputMs = 2200

-- YouTube Search. Paste link works even without API key.
Config.YouTubeApiKey = '' -- vendos YouTube Data API v3 key ketu nese do search real
Config.MaxSearchResults = 12
Config.AutoNext = true
Config.AutoNextFallbackQuery = 'albanian music mix'
Config.TrackFallbackSeconds = 230 -- fallback kur iframe nuk kthen event end

-- xSound resource
Config.XSoundResource = 'xsound'
Config.DefaultRadioVolume = 0.55
Config.MinVolume = 0.01
Config.MaxDistance = 38.0
Config.SoundUpdateMs = 350

-- Realistic audio: brenda paster, jashte mbytur; dyer/xhama e hapin zerin gradualisht.
Config.InsideCabinMultiplier = 1.00
Config.InsideWindowOpenMultiplier = 1.10
Config.InsideDoorOpenMultiplier = 1.18
Config.OutsideClosedMultiplier = 0.12
Config.OutsideWindowOpenMultiplier = 0.42
Config.OutsideDoorOpenMultiplier = 0.82
Config.EngineOffMultiplier = 0.86

-- NUI main UI, si tablet/carplay ne foto. Hapet me F6 vetem kur je ne makine.
Config.Controller = {
    enabled = true,
    startPage = 'home', -- home/music/maps/actions/status/contacts
    keepGameControlWhenClosed = true,
}

-- Screen fizik ne coroshkot. DUI eshte i lidhur me makinen, jo me playerin.
Config.PhysicalScreen = {
    enabled = false, -- V4.9 STABLE: hiqet physical DUI/video/prop sepse YouTube iframe bente glitch ne first-person
    firstPersonOnly = true,      -- true = shfaqet vetem first person ne makine
    sameVehicleOnly = true,
    drawDistance = 5.0,

    -- Prop lokal per trup/ekran ne makine. Nuk eshte networked; duket per lojtarin qe eshte brenda.
    propEnabled = false,
    propModel = 'prop_cs_tablet',
    propVisibleOnlyFirstPerson = true,
    propOffset = vector3(0.0, 0.42, 0.33),
    -- Pak i kthyer anash qe ne first-person te duket sikur tablet fizik ne coroshkot.
    propRotation = vector3(-7.0, 0.0, 7.5),

    -- V4.2 PHYSICAL STREAM MODE
    -- renderMode = 'poly' e vizaton DUI si siperfaqe 3D mbi tablet, jo si overlay 2D.
    -- Kjo e ben screen + tablet te duken si nje trup ne first person.
    renderMode = 'off', -- physical video off per stabilitet
    autoShowMusicOnPlay = false, -- kur luan YouTube, screen fizik kalon vet te video/music
    videoCinemaMode = false, -- ne DUI fizik video hapet me e madhe, pa queue anash
    duiWidth = 1920,
    duiHeight = 1080,

    -- DUI surface mbi prop/dashboard. Nese del lart/poshte ndrysho Z. Nese del para/mbrapa ndrysho Y.
    offset = vector3(0.0, 0.46, 0.345),
    screenRotation = vector3(-7.0, 0.0, 7.5), -- duhet te jete afer propRotation per te qene nje trup
    screenForwardOffset = 0.014, -- e nxjerr stream-in pak perpara prop-it qe mos te futet brenda modelit
    doubleSided = true, -- shihet edhe nese kamera e kap nga pak anash
    width = 0.425, -- madhesia fizike ne metra
    height = 0.239,
    opacity = 252,
    screenScale = 1.0,

    -- per makina custom vendos hash model dhe offset custom
    vehicleOffsets = {
        -- [`adder`] = { offset = vector3(0.0, 0.44, 0.33), propOffset = vector3(0.0, 0.40, 0.315), width = 0.38, height = 0.21, screenScale = 0.90 },
    }
}


-- Live navigation / AI voice. Kur arrin afer waypoint, tableti thote tekstin me voice.
Config.Navigation = {
    ArrivalDistanceMeters = 35.0,
    VoiceEnabled = true,
    VoiceText = 'You have arrived at your waypoint.',
    VoiceLang = 'en-US',
    VoiceVolume = 0.85,
    -- V4.5: zgjidh nga tableti zerin femer/mashkull. Browser do marre voice me te afert qe gjen.
    VoiceGenderDefault = 'female', -- female / male
    ArrivalSound = true,
    ArrivalNotify = true,
    MapMinZoom = 0.6,
    MapMaxZoom = 2.4,
    MapDefaultZoom = 1.0,

    -- V4.4 GPS TALK / EuroTruck style voice guidance.
    -- Voice punon vetem kur lojtari e ben ON nga Maps app ne tablet.
    GpsTalkDefault = false,
    GpsTalkPersist = true,
    TurnInstructionEnabled = true,
    TurnInstructionMeters = 220.0,
    TurnInstructionCooldownMs = 11500,
    TurnAngleDegrees = 32.0,
    StraightInstructionCooldownMs = 42000,
    TurnLeftText = 'In %s turn left.',
    TurnRightText = 'In %s turn right.',
    ContinueText = 'Continue straight for %s.',

    SpeedWarningEnabled = true,
    CitySpeedLimitKmh = 90,
    HighwaySpeedLimitKmh = 130,
    SpeedWarningToleranceKmh = 15,
    SpeedWarningCooldownMs = 18000,
    SpeedWarningText = 'You are driving too fast. Slow down.',

    TrafficLightEnabled = true,
    TrafficLightDistance = 32.0,
    TrafficLightCooldownMs = 9000,
    RedLightText = 'Red traffic light ahead. Stop.',
    GreenLightText = 'Green light. Continue.',
    YellowLightText = 'Yellow traffic light ahead. Be careful.'
}

-- Rear/trunk parking camera
Config.RearCamera = {
    enabled = true,
    fov = 78.0,

    -- V4.6 REAL REAR CAMERA:
    -- Kamera/sensor nuk del me nga qendra e makines. Merr automatikisht fundin e modelit
    -- (rear bumper/trunk/back door) me GetModelDimensions dhe vendoset pak jashte bythes se makines.
    UseModelBounds = true,
    CameraBackFromRear = 0.72,      -- sa cm mbrapa bumperit vendoset kamera
    CameraHeightFromGround = 0.78,  -- lartesia reale nga toka, jo nga qendra e makines
    CameraLookBackDistance = 8.5,   -- pika ku shikon kamera pas makines
    CameraLookDown = 0.18,          -- sa poshte shikon ne toke

    -- Fallback per makina ku model bounds s'jane te sakta
    distanceBack = 3.1,
    height = 0.82,
    pitch = -7.0,
    showGuidelines = true,

    -- V4.6 realistic parking sensors. Rrezet dalin nga bumperi i pasem left/center/right, jo nga qendra.
    SensorsEnabled = true,
    SensorMaxDistance = 5.0,
    SensorRayHeight = 0.62,
    SensorSideOffsetMultiplier = 0.34, -- sa majtas/djathtas nga gjeresia e makines
    SensorStartBehindRear = 0.08,
    SensorBeepEnabled = true,
    SensorBeepVolume = 0.42,
    SensorCloseMeters = 0.55,
    SensorMediumMeters = 1.35,
    SensorFarMeters = 2.65
}

-- Vehicle actions app
Config.VehicleControls = {
    allowPassengerControl = true,
    xenonColorNames = {
        [0] = 'White', [1] = 'Blue', [2] = 'Electric Blue', [3] = 'Mint Green', [4] = 'Lime Green',
        [5] = 'Yellow', [6] = 'Golden Shower', [7] = 'Orange', [8] = 'Red', [9] = 'Pony Pink',
        [10] = 'Hot Pink', [11] = 'Purple', [12] = 'Blacklight'
    }
}

-- Map/weather/card labels. Weather native gives current weather hash; UI maps it to text.
Config.Apps = {
    music = true,
    maps = true,
    actions = true,
    status = true,
    camera = true,
    contacts = true,
}


-- V4.5: GTA style live map / blips / cameras / draggable tablet UI
Config.Map = {
    Style = 'dark', -- dark = si GPS real/GTA i zi, light = stili i vjeter
    ShowServerBlips = true,
    ShowCameras = true,
    MaxBlips = 90,
    -- Sprite ID qe do shfaqen ne tablet. Mund te shtosh sprite te custom blips nga serveri yt.
    BlipSprites = { 1, 8, 38, 40, 50, 52, 56, 60, 61, 66, 67, 68, 72, 73, 77, 78, 80, 85, 93, 110, 120, 121, 135, 147, 162, 164, 171, 225, 226, 227, 251, 280, 285, 304, 305, 357, 402, 408, 431, 446, 475, 477, 480, 488, 500, 521, 532, 545, 566, 590 },
    Cameras = {
        -- shembull: { label = 'Speed Camera', coords = vector3(245.3, -1044.2, 29.2) }
    }
}

Config.TabletUI = {
    Draggable = true,
    SavePosition = true,
    DefaultLeft = '50%',
    DefaultTop = '52%'
}

Config.Contacts = {
    enabled = true,
    refreshMs = 12000,
    jobs = {
        { name = 'police', label = 'Police 911', phone = 'SMS 911', initials = 'PD', icon = 'police' },
        { name = 'ambulance', label = 'EMS 911', phone = 'SMS 911', initials = 'EMS', icon = 'ems' },
        { name = 'doctor', label = 'Doctor 911', phone = 'SMS 911', initials = 'DR', icon = 'ems' },
        { name = 'mechanic', label = 'Mechanic', phone = 'SMS', initials = 'MC', icon = 'mechanic' },
        { name = 'taxi', label = 'Taxi', phone = 'SMS', initials = 'TX', icon = 'taxi' }
    }
}


-- V4.9: Contacts nuk bejne CALL. Bejne vetem SMS/dispatch me blip per job online.
Config.DispatchSMS = {
    enabled = true,
    blipDurationMs = 90000,
    blipSprite = 161,
    blipScale = 1.05,
    defaultMessage = 'Need assistance at my GPS position.',
    jobs = {
        police = { targets = { 'police', 'sheriff', 'fib' }, phone = '911', label = 'Police 911' },
        ambulance = { targets = { 'ambulance', 'doctor', 'ems' }, phone = '911', label = 'EMS 911' },
        doctor = { targets = { 'ambulance', 'doctor', 'ems' }, phone = '911', label = 'EMS 911' },
        mechanic = { targets = { 'mechanic', 'mecano' }, phone = '555-MECH', label = 'Mechanic SMS' },
        taxi = { targets = { 'taxi' }, phone = '555-TAXI', label = 'Taxi SMS' }
    }
}
