local uiOpen = false
local currentVehicle = 0
local currentNetId = nil
local activeRadios = {}
local searchReq = 0
local dui = nil
local duiHandle = nil
local txd = nil
local txn = nil
local duiReady = false
local screenProp = nil
local screenPropVehicle = 0
local rearCam = nil
local rearCamVehicle = 0
local rearCamActive = false
local currentPage = Config.Controller.startPage or 'home'
local cruiseActive = false
local windowsDown = false
local interiorLights = false
local headlightsOn = false
local lastUiState = {}
local lastWaypointSignature = nil
local waypointArrivedSignature = nil
local gpsTalkEnabled = (Config.Navigation and Config.Navigation.GpsTalkDefault) == true
if Config.Navigation and Config.Navigation.GpsTalkPersist ~= false then
    local savedGpsTalk = GetResourceKvpString('rd_carradio_gps_talk')
    if savedGpsTalk ~= nil then gpsTalkEnabled = savedGpsTalk == '1' end
end
local lastTurnPromptAt = 0
local lastTurnPromptKey = ''
local lastStraightPromptAt = 0
local lastSpeedWarnAt = 0
local lastTrafficWarnAt = 0
local lastTrafficWarnKey = ''
local gpsVoiceGender = (Config.Navigation and Config.Navigation.VoiceGenderDefault) or 'female'
if Config.Navigation then
    local savedVoiceGender = GetResourceKvpString('rd_carradio_voice_gender')
    if savedVoiceGender == 'male' or savedVoiceGender == 'female' then gpsVoiceGender = savedVoiceGender end
end
local lastContactsRequestAt = 0
local lastSensorBeepAt = 0
local lastVehicleExitAt = 0
local forcedExitUntil = 0
local sendDui
local stopRearCamera
local requestVehicleExit

local function dbg(...)
    if Config.Debug then print('[RD_carradio]', ...) end
end

local function notify(msg, ntype)
    msg = tostring(msg or '')
    ntype = ntype or 'primary'
    local fw = (Config.Framework or 'auto'):lower()
    if (fw == 'qb' or fw == 'auto') and GetResourceState('qb-core') == 'started' then
        local ok, QBCore = pcall(function() return exports['qb-core']:GetCoreObject() end)
        if ok and QBCore and QBCore.Functions and QBCore.Functions.Notify then
            QBCore.Functions.Notify(msg:gsub('~.-~', ''), ntype, 4500)
            return
        end
    end
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end

local function nuiKeepInput(enabled)
    -- Keep input lets F / ESC still work while the tablet has mouse focus.
    if SetNuiFocusKeepInput then
        SetNuiFocusKeepInput(enabled == true)
    end
end

local function sendNavigationVoice(text, withSound)
    local nav = Config.Navigation or {}
    if nav.VoiceEnabled == false or not gpsTalkEnabled then return end
    local payload = {
        action = 'speak',
        text = text or nav.VoiceText or 'You have arrived at your waypoint.',
        lang = nav.VoiceLang or 'en-US',
        volume = nav.VoiceVolume or 0.85,
        gender = gpsVoiceGender
    }
    SendNUIMessage(payload)
    -- Nuk ja dergoj DUI-t per te mos folur dy here nga dy browser pages.
    if withSound ~= false and nav.ArrivalSound ~= false then
        PlaySoundFrontend(-1, 'CHECKPOINT_NORMAL', 'HUD_MINI_GAME_SOUNDSET', true)
    end
end

local function sendSensorBeep(sensor)
    if not sensor or not sensor.hit then return end
    local cfg = Config.RearCamera or {}
    if cfg.SensorBeepEnabled == false then return end
    local dist = tonumber(sensor.distance) or 99.0
    local interval = 0
    if dist <= (cfg.SensorCloseMeters or 0.55) then interval = 120
    elseif dist <= (cfg.SensorMediumMeters or 1.35) then interval = 260
    elseif dist <= (cfg.SensorFarMeters or 2.65) then interval = 560
    else return end

    local now = GetGameTimer()
    if now - lastSensorBeepAt < interval then return end
    lastSensorBeepAt = now
    SendNUIMessage({ action = 'sensorBeep', distance = dist, level = sensor.level or 0, volume = cfg.SensorBeepVolume or 0.42 })
    sendDui({ action = 'sensorBeep', distance = dist, level = sensor.level or 0, volume = math.min((cfg.SensorBeepVolume or 0.42) * 0.55, 0.35) })
    PlaySoundFrontend(-1, 'Beep_Red', 'DLC_HEIST_HACKING_SNAKE_SOUNDS', true)
end


local function xsoundReady()
    return GetResourceState(Config.XSoundResource) == 'started'
end

local function soundName(netId)
    return ('rd_carradio_%s'):format(netId)
end

local function youtubeUrl(videoId)
    return ('https://www.youtube.com/watch?v=%s'):format(videoId)
end

local function clamp(n, min, max)
    n = tonumber(n) or min
    if n < min then return min end
    if n > max then return max end
    return n
end

local function getControlVehicle()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then return 0 end
    return GetVehiclePedIsIn(ped, false)
end

local function modelName(veh)
    if not veh or veh == 0 then return 'Vehicle' end
    local label = GetDisplayNameFromVehicleModel(GetEntityModel(veh))
    local text = GetLabelText(label)
    if text and text ~= 'NULL' then return text end
    return label or 'Vehicle'
end

local function getStreetAndZone(coords)
    local streetHash, crossingHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local street = streetHash and GetStreetNameFromHashKey(streetHash) or 'Unknown street'
    local crossing = crossingHash and crossingHash ~= 0 and GetStreetNameFromHashKey(crossingHash) or ''
    local zone = GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))
    if not zone or zone == 'NULL' then zone = 'Los Santos' end
    return street, crossing, zone
end

local function headingLabel(h)
    h = (tonumber(h) or 0.0) % 360.0
    local dirs = { 'N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW' }
    return dirs[math.floor((h + 22.5) / 45.0) % 8 + 1]
end

local function weatherLabel()
    local map = {
        [GetHashKey('EXTRASUNNY')] = 'Extra Sunny',
        [GetHashKey('CLEAR')] = 'Clear',
        [GetHashKey('CLOUDS')] = 'Clouds',
        [GetHashKey('OVERCAST')] = 'Overcast',
        [GetHashKey('RAIN')] = 'Rain',
        [GetHashKey('THUNDER')] = 'Thunder',
        [GetHashKey('SMOG')] = 'Smog',
        [GetHashKey('FOGGY')] = 'Foggy',
        [GetHashKey('XMAS')] = 'Snow',
        [GetHashKey('SNOWLIGHT')] = 'Snow Light',
        [GetHashKey('BLIZZARD')] = 'Blizzard',
        [GetHashKey('HALLOWEEN')] = 'Halloween'
    }
    local w = GetPrevWeatherTypeHashName and GetPrevWeatherTypeHashName() or nil
    return (w and map[w]) or 'Live Weather'
end

local function anyDoorOpen(veh)
    for i = 0, 5 do
        if GetVehicleDoorAngleRatio(veh, i) > 0.08 then return true end
    end
    return false
end

local function anyWindowOpen(veh)
    for i = 0, 3 do
        if not IsVehicleWindowIntact(veh, i) then return true end
    end
    return false
end

local function listenerInsideVehicle(veh)
    local ped = PlayerPedId()
    return IsPedInAnyVehicle(ped, false) and GetVehiclePedIsIn(ped, false) == veh
end

local function calcVolume(veh, userVolume)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return Config.MinVolume end
    local base = tonumber(userVolume) or Config.DefaultRadioVolume
    local inside, doorOpen, windowOpen = listenerInsideVehicle(veh), anyDoorOpen(veh), anyWindowOpen(veh)
    local mult
    if inside then
        if doorOpen then mult = Config.InsideDoorOpenMultiplier
        elseif windowOpen then mult = Config.InsideWindowOpenMultiplier
        else mult = Config.InsideCabinMultiplier end
    else
        if doorOpen then mult = Config.OutsideDoorOpenMultiplier
        elseif windowOpen then mult = Config.OutsideWindowOpenMultiplier
        else mult = Config.OutsideClosedMultiplier end
    end
    if not GetIsVehicleEngineRunning(veh) then mult = mult * Config.EngineOffMultiplier end
    return clamp(base * mult, Config.MinVolume, 1.0)
end

local function ensureDui()
    if dui then return end
    local url = ('nui://%s/html/dui.html'):format(GetCurrentResourceName())
    local duiW = (Config.PhysicalScreen and Config.PhysicalScreen.duiWidth) or 1920
    local duiH = (Config.PhysicalScreen and Config.PhysicalScreen.duiHeight) or 1080
    dui = CreateDui(url, duiW, duiH)
    duiHandle = GetDuiHandle(dui)
    txd = CreateRuntimeTxd('rd_carradio_txd')
    txn = CreateRuntimeTextureFromDuiHandle(txd, 'rd_carradio_screen', duiHandle)
    duiReady = true
    if dui then
        SendDuiMessage(dui, json.encode({ action = 'physicalConfig', videoCinemaMode = Config.PhysicalScreen and Config.PhysicalScreen.videoCinemaMode, mapStyle = Config.Map and Config.Map.Style or 'dark' }))
    end
end

sendDui = function(data)
    if not (Config.PhysicalScreen and Config.PhysicalScreen.enabled) then return end
    ensureDui()
    if dui then SendDuiMessage(dui, json.encode(data)) end
end

local function sendUi(data)
    SendNUIMessage(data)
    sendDui(data)
end

local function sendControllerOnly(data)
    SendNUIMessage(data)
end

local function updateDuiFromRadio(netId)
    if not (Config.PhysicalScreen and Config.PhysicalScreen.enabled) then return end
    local r = activeRadios[netId]
    if r then
        sendDui({ action = 'radio', radio = r })
    else
        sendDui({ action = 'radioStop' })
    end
end

local function startSound(netId, data)
    local veh = NetToVeh(netId)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    data.startedLocal = GetGameTimer()
    activeRadios[netId] = data

    if xsoundReady() then
        local name = soundName(netId)
        local coords = GetEntityCoords(veh)
        if exports[Config.XSoundResource]:soundExists(name) then
            exports[Config.XSoundResource]:Destroy(name)
        end
        exports[Config.XSoundResource]:PlayUrlPos(name, youtubeUrl(data.videoId), calcVolume(veh, data.volume), coords, false)
        exports[Config.XSoundResource]:Distance(name, Config.MaxDistance)
    else
        notify('~r~xsound nuk eshte started. ensure xsound para RD_carradio.')
    end

    updateDuiFromRadio(netId)
    if Config.PhysicalScreen and Config.PhysicalScreen.enabled and Config.PhysicalScreen.autoShowMusicOnPlay then
        sendDui({ action = 'setPage', page = 'music' })
    end
    if currentNetId == netId then
        sendControllerOnly({ action = 'radio', radio = data })
    end
end

local function stopSound(netId)
    if xsoundReady() then
        local name = soundName(netId)
        if exports[Config.XSoundResource]:soundExists(name) then
            exports[Config.XSoundResource]:Destroy(name)
        end
    end
    activeRadios[netId] = nil
    updateDuiFromRadio(netId)
    if currentNetId == netId then sendControllerOnly({ action = 'radioStop' }) end
end

CreateThread(function()
    while true do
        Wait(Config.SoundUpdateMs)
        if xsoundReady() then
            for netId, data in pairs(activeRadios) do
                local veh = NetToVeh(tonumber(netId))
                local name = soundName(netId)
                if veh and veh ~= 0 and DoesEntityExist(veh) and exports[Config.XSoundResource]:soundExists(name) then
                    exports[Config.XSoundResource]:Position(name, GetEntityCoords(veh))
                    exports[Config.XSoundResource]:Distance(name, Config.MaxDistance)
                    exports[Config.XSoundResource]:setVolume(name, calcVolume(veh, data.volume))
                end
            end
        end
    end
end)

local function getScreenCfg(veh)
    local cfg = Config.PhysicalScreen
    local model = GetEntityModel(veh)
    local custom = cfg.vehicleOffsets and cfg.vehicleOffsets[model] or nil
    if custom then
        return {
            offset = custom.offset or cfg.offset,
            propOffset = custom.propOffset or cfg.propOffset,
            propRotation = custom.propRotation or cfg.propRotation,
            width = custom.width or cfg.width,
            height = custom.height or cfg.height,
            screenScale = custom.screenScale or cfg.screenScale,
            opacity = custom.opacity or cfg.opacity,
            propModel = custom.propModel or cfg.propModel,
            renderMode = custom.renderMode or cfg.renderMode,
            screenRotation = custom.screenRotation or cfg.screenRotation or custom.propRotation or cfg.propRotation,
            screenForwardOffset = custom.screenForwardOffset or cfg.screenForwardOffset,
            doubleSided = custom.doubleSided == nil and cfg.doubleSided or custom.doubleSided
        }
    end
    return {
        offset = cfg.offset,
        propOffset = cfg.propOffset,
        propRotation = cfg.propRotation,
        width = cfg.width,
        height = cfg.height,
        screenScale = cfg.screenScale,
        opacity = cfg.opacity,
        propModel = cfg.propModel,
        renderMode = cfg.renderMode,
        screenRotation = cfg.screenRotation or cfg.propRotation,
        screenForwardOffset = cfg.screenForwardOffset,
        doubleSided = cfg.doubleSided
    }
end

local function isFirstPersonVehicleCam()
    return GetFollowVehicleCamViewMode() == 4 or GetFollowPedCamViewMode() == 4
end

local function deleteScreenProp()
    if screenProp and DoesEntityExist(screenProp) then
        DeleteEntity(screenProp)
    end
    screenProp = nil
    screenPropVehicle = 0
end

local function loadModel(model)
    local hash = type(model) == 'number' and model or GetHashKey(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local timeout = GetGameTimer() + 2500
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(0) end
    if not HasModelLoaded(hash) then return nil end
    return hash
end

local function ensureScreenProp(veh)
    if not Config.PhysicalScreen.propEnabled then return end
    if not veh or veh == 0 or not DoesEntityExist(veh) then deleteScreenProp(); return end
    if screenProp and screenPropVehicle == veh and DoesEntityExist(screenProp) then return end

    deleteScreenProp()
    local cfg = getScreenCfg(veh)
    local hash = loadModel(cfg.propModel or Config.PhysicalScreen.propModel)
    if not hash then return end

    local coords = GetEntityCoords(veh)
    screenProp = CreateObjectNoOffset(hash, coords.x, coords.y, coords.z, false, false, false)
    screenPropVehicle = veh
    SetEntityCollision(screenProp, false, false)
    if SetEntityCompletelyDisableCollision then SetEntityCompletelyDisableCollision(screenProp, true, true) end
    SetEntityAlpha(screenProp, 255, false)
    SetEntityLodDist(screenProp, 50)
    AttachEntityToEntity(
        screenProp, veh, 0,
        cfg.propOffset.x, cfg.propOffset.y, cfg.propOffset.z,
        cfg.propRotation.x, cfg.propRotation.y, cfg.propRotation.z,
        false, false, false, false, 2, true
    )
    SetModelAsNoLongerNeeded(hash)
end

local function rotateLocalVector(v, rot)
    rot = rot or vector3(0.0, 0.0, 0.0)
    local x, y, z = v.x or 0.0, v.y or 0.0, v.z or 0.0
    local rx = math.rad(rot.x or 0.0)
    local ry = math.rad(rot.y or 0.0)
    local rz = math.rad(rot.z or 0.0)

    local cx, sx = math.cos(rx), math.sin(rx)
    y, z = (y * cx - z * sx), (y * sx + z * cx)

    local cy, sy = math.cos(ry), math.sin(ry)
    x, z = (x * cy + z * sy), (-x * sy + z * cy)

    local cz, sz = math.cos(rz), math.sin(rz)
    x, y = (x * cz - y * sz), (x * sz + y * cz)

    return vector3(x, y, z)
end

local function drawDuiPoly(veh, cfg)
    if not DrawSpritePoly then return false end

    local scale = cfg.screenScale or 1.0
    local w = (cfg.width or 0.40) * scale
    local h = (cfg.height or 0.225) * scale
    local forward = cfg.screenForwardOffset or 0.012
    local rot = cfg.screenRotation or cfg.propRotation or vector3(0.0, 0.0, 0.0)

    local function corner(dx, dz)
        local rel = rotateLocalVector(vector3(dx, forward, dz), rot)
        return GetOffsetFromEntityInWorldCoords(veh, cfg.offset.x + rel.x, cfg.offset.y + rel.y, cfg.offset.z + rel.z)
    end

    local tl = corner(-w / 2.0,  h / 2.0)
    local tr = corner( w / 2.0,  h / 2.0)
    local br = corner( w / 2.0, -h / 2.0)
    local bl = corner(-w / 2.0, -h / 2.0)
    local a = cfg.opacity or 252

    -- Siperfaqe 3D e vertete: dy triangles me UV te DUI texture.
    DrawSpritePoly(tl.x, tl.y, tl.z, tr.x, tr.y, tr.z, bl.x, bl.y, bl.z, 255, 255, 255, a, 'rd_carradio_txd', 'rd_carradio_screen', 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0)
    DrawSpritePoly(tr.x, tr.y, tr.z, br.x, br.y, br.z, bl.x, bl.y, bl.z, 255, 255, 255, a, 'rd_carradio_txd', 'rd_carradio_screen', 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0)

    -- Double side per first-person kur kamera e kap ekranin pak nga anash/poshte.
    if cfg.doubleSided ~= false then
        DrawSpritePoly(tl.x, tl.y, tl.z, bl.x, bl.y, bl.z, tr.x, tr.y, tr.z, 255, 255, 255, a, 'rd_carradio_txd', 'rd_carradio_screen', 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0)
        DrawSpritePoly(tr.x, tr.y, tr.z, bl.x, bl.y, bl.z, br.x, br.y, br.z, 255, 255, 255, a, 'rd_carradio_txd', 'rd_carradio_screen', 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0)
    end

    return true
end

local function drawDuiBillboard(veh, cfg)
    local pos = GetOffsetFromEntityInWorldCoords(veh, cfg.offset.x, cfg.offset.y, cfg.offset.z)
    local onScreen, sx, sy = World3dToScreen2d(pos.x, pos.y, pos.z)
    if not onScreen then return end
    local camCoords = GetGameplayCamCoord()
    local dist = #(camCoords - pos)
    local distScale = clamp((cfg.screenScale or 1.0) / math.max(1.0, dist * 1.10), 0.42, 1.00)
    DrawSprite('rd_carradio_txd', 'rd_carradio_screen', sx, sy, (cfg.width or 0.40) * distScale, (cfg.height or 0.22) * distScale, 0.0, 255, 255, 255, cfg.opacity or 245)
end

local function drawDashboardScreen(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) or not duiReady then return end
    local cfg = getScreenCfg(veh)
    local pos = GetOffsetFromEntityInWorldCoords(veh, cfg.offset.x, cfg.offset.y, cfg.offset.z)
    local camCoords = GetGameplayCamCoord()
    local dist = #(camCoords - pos)
    if dist > (Config.PhysicalScreen.drawDistance or 5.0) then return end

    if (cfg.renderMode or Config.PhysicalScreen.renderMode) == 'poly' and drawDuiPoly(veh, cfg) then
        return
    end

    drawDuiBillboard(veh, cfg)
end

local function getWaypointInfo(veh)
    local blip = GetFirstBlipInfoId(8)
    local coords = veh ~= 0 and GetEntityCoords(veh) or GetEntityCoords(PlayerPedId())
    if DoesBlipExist(blip) then
        local wp = GetBlipInfoIdCoord(blip)
        local dx, dy = wp.x - coords.x, wp.y - coords.y
        local dist2d = math.sqrt(dx * dx + dy * dy)
        local dist3d = #(coords - wp)
        local speedMs = veh ~= 0 and GetEntitySpeed(veh) or 0.0
        local speedKmh = math.floor((speedMs * 3.6) + 0.5)
        local etaSeconds = 0
        if speedMs > 2.0 then etaSeconds = math.floor(dist2d / speedMs) end
        local bearing = (math.deg(math.atan(dx, dy)) + 360.0) % 360.0
        local heading = veh ~= 0 and GetEntityHeading(veh) or GetEntityHeading(PlayerPedId())
        local relative = ((bearing - heading + 540.0) % 360.0) - 180.0
        local wpStreetHash = GetStreetNameAtCoord(wp.x, wp.y, wp.z)
        local wpStreet = wpStreetHash and GetStreetNameFromHashKey(wpStreetHash) or 'Waypoint'
        local distanceText = dist2d < 1000.0 and ('%d m'):format(math.floor(dist2d + 0.5)) or ('%.1f km'):format(dist2d / 1000.0)
        return {
            active = true,
            distanceKm = dist2d / 1000.0,
            distanceText = distanceText,
            distanceMeters = math.floor(dist2d + 0.5),
            avgSpeed = speedKmh,
            etaSeconds = etaSeconds,
            bearing = bearing,
            relativeAngle = relative,
            waypointStreet = wpStreet,
            waypoint = { x = wp.x, y = wp.y, z = wp.z },
            signature = ('%.0f:%.0f'):format(wp.x, wp.y)
        }
    end
    return { active = false, distanceText = 'No waypoint', distanceKm = 0.0, distanceMeters = 0, avgSpeed = 0, etaSeconds = 0 }
end


local function formatMeters(meters)
    meters = tonumber(meters) or 0.0
    if meters < 1000.0 then return ('%d m'):format(math.floor(meters + 0.5)) end
    return ('%.1f km'):format(meters / 1000.0)
end

local function speedLimitForRoad(street)
    local nav = Config.Navigation or {}
    street = tostring(street or ''):lower()
    if street:find('highway') or street:find('freeway') or street:find('fwy') or street:find('hwy') or street:find('ocean') then
        return nav.HighwaySpeedLimitKmh or 130
    end
    return nav.CitySpeedLimitKmh or 90
end

local trafficLightModels = {
    'prop_traffic_01a', 'prop_traffic_01b', 'prop_traffic_01d',
    'prop_traffic_02a', 'prop_traffic_02b', 'prop_traffic_03a', 'prop_traffic_03b'
}

local function getNativeTrafficLightState(veh)
    -- Disa artifacts kane native-in GET_VEHICLE_TRAFFICLIGHT_STATE, disa jo.
    -- pcall e mban script-in safe ne cdo build.
    if type(GetVehicleTrafficLightState) ~= 'function' then return nil end
    local ok, state = pcall(GetVehicleTrafficLightState, veh)
    if not ok then return nil end
    state = tonumber(state)
    if not state then return nil end
    -- Shume artifacts kthejne 0=green, 1=red, 2=yellow. Ne fallback poshte kemi cycle.
    if state == 0 then return 'green' end
    if state == 1 then return 'red' end
    if state == 2 then return 'yellow' end
    return nil
end

local function findNearestTrafficLight(veh, maxDist)
    local vehCoords = GetEntityCoords(veh)
    local fwd = GetEntityForwardVector(veh)
    local bestObj, bestDist = 0, maxDist or 32.0
    for _, model in ipairs(trafficLightModels) do
        local obj = GetClosestObjectOfType(vehCoords.x, vehCoords.y, vehCoords.z, maxDist or 32.0, GetHashKey(model), false, false, false)
        if obj and obj ~= 0 and DoesEntityExist(obj) then
            local oc = GetEntityCoords(obj)
            local diff = oc - vehCoords
            local d = #(diff)
            if d < bestDist then
                local len = math.max(d, 0.01)
                local dot = (diff.x / len) * fwd.x + (diff.y / len) * fwd.y + (diff.z / len) * fwd.z
                if dot > 0.10 then
                    bestObj, bestDist = obj, d
                end
            end
        end
    end
    return bestObj, bestDist
end

local function getTrafficLightInfo(veh)
    local nav = Config.Navigation or {}
    if nav.TrafficLightEnabled == false or not veh or veh == 0 or not DoesEntityExist(veh) then
        return { active = false }
    end
    local maxDist = nav.TrafficLightDistance or 32.0
    local obj, dist = findNearestTrafficLight(veh, maxDist)
    if not obj or obj == 0 then return { active = false } end

    local stateName = getNativeTrafficLightState(veh)
    if not stateName then
        -- Fallback visual/cycle. Nuk prek trafikun e lojes, vetem jep sinjal ne tablet.
        local cycle = math.floor((GetGameTimer() / 1000) % 40)
        if cycle < 19 then stateName = 'green'
        elseif cycle < 24 then stateName = 'yellow'
        else stateName = 'red' end
    end

    return {
        active = true,
        state = stateName,
        distance = math.floor((dist or maxDist) + 0.5),
        distanceText = formatMeters(dist or maxDist)
    }
end


local function getVehicleModelBounds(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return nil, nil end
    local ok, minDim, maxDim = pcall(function()
        local mn, mx = GetModelDimensions(GetEntityModel(veh))
        return mn, mx
    end)
    if ok and minDim and maxDim then
        return minDim, maxDim
    end
    return nil, nil
end

local function getRearBounds(veh)
    local minDim, maxDim = getVehicleModelBounds(veh)
    if not minDim or not maxDim then
        -- fallback i sigurte per makina ku GetModelDimensions nuk kthen vlera
        return {
            min = vector3(-0.95, -2.15, -0.45),
            max = vector3(0.95, 2.15, 0.95),
            rearY = -1.15,
            width = 1.90,
            height = 1.40
        }
    end

    -- Ne GTA/FiveM local Y negative eshte pjesa e pasme e makines.
    return {
        min = minDim,
        max = maxDim,
        rearY = minDim.y,
        width = math.max(1.25, (maxDim.x - minDim.x)),
        height = math.max(0.85, (maxDim.z - minDim.z))
    }
end

local function getRearCameraTransform(veh)
    local cfg = Config.RearCamera or {}
    if cfg.UseModelBounds == false then
        local coords = GetOffsetFromEntityInWorldCoords(veh, 0.0, -(cfg.distanceBack or 3.0), cfg.height or 0.8)
        return coords, nil, false
    end

    local b = getRearBounds(veh)
    local minZ = b.min and b.min.z or -0.45
    local maxZ = b.max and b.max.z or 0.95
    local rearY = b.rearY or -1.15

    -- Kamera eshte ne bythen e makines, pak jashte bumperit/trunkut, jo ne qender te modelit.
    local z = minZ + (cfg.CameraHeightFromGround or 0.92)
    z = clamp(z, minZ + 0.42, maxZ + 0.12)
    local camY = rearY - (cfg.CameraBackFromRear or 0.16)
    local lookY = rearY - (cfg.CameraLookBackDistance or 8.5)
    local lookZ = z - (cfg.CameraLookDown or 0.35)

    local camCoords = GetOffsetFromEntityInWorldCoords(veh, 0.0, camY, z)
    local lookCoords = GetOffsetFromEntityInWorldCoords(veh, 0.0, lookY, lookZ)
    return camCoords, lookCoords, true
end

local function getParkingSensor(veh)
    local cfg = Config.RearCamera or {}
    if cfg.SensorsEnabled == false or not veh or veh == 0 or not DoesEntityExist(veh) then
        return { active = false, hit = false, distance = cfg.SensorMaxDistance or 5.0, level = 0 }
    end

    local maxDist = cfg.SensorMaxDistance or 5.0
    local b = getRearBounds(veh)
    local rearY = b.rearY or -1.15
    local minZ = b.min and b.min.z or -0.45
    local width = b.width or 1.9
    local rayZ = minZ + (cfg.SensorRayHeight or 0.62)
    local startY = rearY - (cfg.SensorStartBehindRear or 0.08)
    local side = width * (cfg.SensorSideOffsetMultiplier or 0.34)

    -- Tre sensore si makine reale: left / center / right nga bumperi i pasem.
    local rays = {
        { name = 'left', x = -side },
        { name = 'center', x = 0.0 },
        { name = 'right', x = side }
    }

    local best = { hit = false, distance = maxDist, level = 0, side = 'none', entity = 0 }
    for _, r in ipairs(rays) do
        local origin = GetOffsetFromEntityInWorldCoords(veh, r.x, startY, rayZ)
        local target = GetOffsetFromEntityInWorldCoords(veh, r.x, startY - maxDist, rayZ)
        local ray = StartShapeTestRay(origin.x, origin.y, origin.z, target.x, target.y, target.z, 1 + 2 + 4 + 8 + 16, veh, 7)
        local _, hit, endCoords, _, entityHit = GetShapeTestResult(ray)
        local didHit = hit == 1 or hit == true
        if didHit and endCoords then
            local dist = #(origin - endCoords)
            if dist < best.distance then
                best.hit = true
                best.distance = dist
                best.side = r.name
                best.entity = entityHit or 0
            end
        end
    end

    if best.hit then
        if best.distance <= (cfg.SensorCloseMeters or 0.55) then best.level = 4
        elseif best.distance <= (cfg.SensorMediumMeters or 1.35) then best.level = 3
        elseif best.distance <= (cfg.SensorFarMeters or 2.65) then best.level = 2
        else best.level = 1 end
    end

    return {
        active = true,
        hit = best.hit,
        distance = best.distance,
        distanceText = formatMeters(best.distance),
        level = best.level,
        side = best.side,
        entity = best.entity
    }
end

local function handleGpsGuidance(veh, state)
    local nav = Config.Navigation or {}
    if not gpsTalkEnabled or nav.VoiceEnabled == false or not state or not state.inVehicle then return end
    local now = GetGameTimer()
    local wp = state.waypoint
    local speed = tonumber(state.speed) or 0

    if nav.SpeedWarningEnabled ~= false then
        local limit = speedLimitForRoad(state.street)
        local tolerance = nav.SpeedWarningToleranceKmh or 15
        if speed > (limit + tolerance) and now - lastSpeedWarnAt > (nav.SpeedWarningCooldownMs or 18000) then
            lastSpeedWarnAt = now
            sendNavigationVoice(nav.SpeedWarningText or 'You are driving too fast. Slow down.', false)
            SendNUIMessage({ action = 'navAlert', kind = 'speed', text = nav.SpeedWarningText or 'You are driving too fast. Slow down.' })
        end
    end

    local tl = state.trafficLight
    if tl and tl.active and speed > 3 then
        local key = (tl.state or 'none') .. ':' .. tostring(math.floor((tl.distance or 0) / 6))
        if key ~= lastTrafficWarnKey and now - lastTrafficWarnAt > (nav.TrafficLightCooldownMs or 9000) then
            lastTrafficWarnKey = key
            lastTrafficWarnAt = now
            if tl.state == 'red' and (tl.distance or 999) <= (nav.TrafficLightDistance or 32.0) then
                sendNavigationVoice(nav.RedLightText or 'Red traffic light ahead. Stop.', false)
            elseif tl.state == 'yellow' and (tl.distance or 999) <= 24.0 then
                sendNavigationVoice(nav.YellowLightText or 'Yellow traffic light ahead. Be careful.', false)
            elseif tl.state == 'green' and (tl.distance or 999) <= 18.0 then
                sendNavigationVoice(nav.GreenLightText or 'Green light. Continue.', false)
            end
        end
    end

    if nav.TurnInstructionEnabled == false or not wp or not wp.active then return end
    if speed < 4 then return end
    local dist = tonumber(wp.distanceMeters) or 999999
    if dist <= (nav.ArrivalDistanceMeters or 35.0) or dist > (nav.TurnInstructionMeters or 220.0) then return end

    local rel = tonumber(wp.relativeAngle) or 0.0
    local angle = nav.TurnAngleDegrees or 32.0
    local direction, text
    if rel > angle then
        direction = 'right'
        text = (nav.TurnRightText or 'In %s turn right.'):format(formatMeters(dist))
    elseif rel < -angle then
        direction = 'left'
        text = (nav.TurnLeftText or 'In %s turn left.'):format(formatMeters(dist))
    else
        direction = 'straight'
        if now - lastStraightPromptAt < (nav.StraightInstructionCooldownMs or 42000) then return end
        lastStraightPromptAt = now
        text = (nav.ContinueText or 'Continue straight for %s.'):format(formatMeters(dist))
    end

    local bucket = math.floor(dist / 40.0)
    local key = direction .. ':' .. tostring(bucket)
    if direction ~= 'straight' and key == lastTurnPromptKey and now - lastTurnPromptAt < (nav.TurnInstructionCooldownMs or 11500) then return end
    if direction ~= 'straight' and now - lastTurnPromptAt < (nav.TurnInstructionCooldownMs or 11500) then return end
    lastTurnPromptKey = key
    lastTurnPromptAt = now
    sendNavigationVoice(text, false)
    SendNUIMessage({ action = 'navAlert', kind = direction, text = text })
end


local function collectMapBlips(veh)
    local mapCfg = Config.Map or {}
    if mapCfg.ShowServerBlips == false then return {} end
    local origin = veh ~= 0 and DoesEntityExist(veh) and GetEntityCoords(veh) or GetEntityCoords(PlayerPedId())
    local out, seen = {}, {}
    local max = tonumber(mapCfg.MaxBlips) or 90
    local sprites = mapCfg.BlipSprites or {}
    for _, sprite in ipairs(sprites) do
        local blip = GetFirstBlipInfoId(tonumber(sprite) or 1)
        local guard = 0
        while blip and blip ~= 0 and DoesBlipExist(blip) and #out < max and guard < 200 do
            guard = guard + 1
            local key = tostring(blip)
            if not seen[key] then
                seen[key] = true
                local coord = GetBlipInfoIdCoord(blip)
                if coord then
                    local dx, dy = coord.x - origin.x, coord.y - origin.y
                    local dist = math.sqrt(dx * dx + dy * dy)
                    if dist < 6500.0 and dist > 1.0 then
                        local label = 'Blip'
                        local okName, name = pcall(function() return GetBlipNameFromTextFile(GetBlipInfoIdDisplay(blip)) end)
                        if okName and name and name ~= '' and name ~= 'NULL' then label = name end
                        out[#out + 1] = {
                            x = coord.x, y = coord.y, z = coord.z,
                            dx = dx, dy = dy, distance = math.floor(dist + 0.5),
                            sprite = tonumber(sprite) or 1,
                            label = label,
                            kind = 'server'
                        }
                    end
                end
            end
            blip = GetNextBlipInfoId(tonumber(sprite) or 1)
        end
        if #out >= max then break end
    end

    if mapCfg.ShowCameras ~= false and type(mapCfg.Cameras) == 'table' then
        for _, cam in ipairs(mapCfg.Cameras) do
            if #out >= max then break end
            if cam.coords then
                local c = cam.coords
                local dx, dy = c.x - origin.x, c.y - origin.y
                local dist = math.sqrt(dx * dx + dy * dy)
                if dist < 3500.0 then
                    out[#out + 1] = { x = c.x, y = c.y, z = c.z, dx = dx, dy = dy, distance = math.floor(dist + 0.5), sprite = 184, label = cam.label or 'Camera', kind = 'camera' }
                end
            end
        end
    end
    return out
end

local function collectVehicleState(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) then
        return { inVehicle = false, page = currentPage, ui = { serverName = Config.ServerName or 'EAGLE CITY RP', musicBannerText = Config.ServerSubtitle or 'Audio-only mode • xSound' }, time = string.format('%02d:%02d', GetClockHours(), GetClockMinutes()), navigation = { gpsTalk = gpsTalkEnabled, voiceGender = gpsVoiceGender }, trafficLight = { active = false }, map = { style = Config.Map and Config.Map.Style or 'dark', blips = {}, cameras = {} } }
    end

    local coords = GetEntityCoords(veh)
    local street, crossing, zone = getStreetAndZone(coords)
    local netId = VehToNet(veh)
    local wp = getWaypointInfo(veh)
    local trafficLight = getTrafficLightInfo(veh)
    local mapBlips = collectMapBlips(veh)
    local speed = math.floor((GetEntitySpeed(veh) * 3.6) + 0.5)
    local fuel = math.floor((GetVehicleFuelLevel(veh) or 0.0) + 0.5)
    local engineHealth = clamp(GetVehicleEngineHealth(veh) / 10.0, 0.0, 100.0)
    local bodyHealth = clamp(GetVehicleBodyHealth(veh) / 10.0, 0.0, 100.0)
    local oil = clamp((GetVehicleOilLevel(veh) or 0.0) * 10.0, 0.0, 100.0)
    local temp = math.floor((GetVehicleEngineTemperature(veh) or 0.0) + 0.5)
    local dirt = math.floor(clamp((GetVehicleDirtLevel(veh) or 0.0) / 15.0 * 100.0, 0.0, 100.0) + 0.5)
    local tyresBurst = false
    for i = 0, 7 do
        if IsVehicleTyreBurst(veh, i, false) then tyresBurst = true break end
    end

    return {
        inVehicle = true,
        netId = netId,
        page = currentPage,
        ui = {
            serverName = Config.ServerName or 'EAGLE CITY RP',
            musicBannerText = Config.ServerSubtitle or 'Audio-only mode • xSound'
        },
        model = modelName(veh),
        plate = GetVehicleNumberPlateText(veh),
        vehicleClass = GetVehicleClass(veh),
        modelHash = GetEntityModel(veh),
        speed = speed,
        speedText = tostring(speed),
        fuel = clamp(fuel, 0, 100),
        weather = weatherLabel(),
        time = string.format('%02d:%02d', GetClockHours(), GetClockMinutes()),
        street = street,
        crossing = crossing,
        zone = zone,
        coords = { x = coords.x, y = coords.y, z = coords.z },
        heading = math.floor(GetEntityHeading(veh) + 0.5),
        headingLabel = headingLabel(GetEntityHeading(veh)),
        waypoint = wp,
        trafficLight = trafficLight,
        navigation = {
            gpsTalk = gpsTalkEnabled,
            voiceGender = gpsVoiceGender,
            speedLimit = speedLimitForRoad(street)
        },
        map = {
            style = Config.Map and Config.Map.Style or 'dark',
            blips = mapBlips
        },
        radio = activeRadios[netId],
        health = {
            engineTemp = temp,
            oil = math.floor(oil + 0.5),
            fuelTank = clamp(fuel, 0, 100),
            engine = math.floor(engineHealth + 0.5),
            body = math.floor(bodyHealth + 0.5),
            tyres = tyresBurst and 'BURST' or 'NO',
            dirt = dirt
        },
        controls = {
            locked = GetVehicleDoorLockStatus(veh) >= 2,
            doorsOpen = anyDoorOpen(veh),
            windowsOpen = anyWindowOpen(veh),
            interiorLights = interiorLights,
            headlights = headlightsOn,
            cruise = cruiseActive,
            engineOn = GetIsVehicleEngineRunning(veh)
        }
    }
end

local function pushState(veh, controllerOnly)
    local state = collectVehicleState(veh)
    lastUiState = state

    local nav = Config.Navigation or {}
    if state and state.waypoint and state.waypoint.active then
        local sig = state.waypoint.signature
        if sig ~= lastWaypointSignature then
            lastWaypointSignature = sig
            waypointArrivedSignature = nil
        end
        local arriveMeters = nav.ArrivalDistanceMeters or 35.0
        if sig and waypointArrivedSignature ~= sig and (state.waypoint.distanceMeters or 99999) <= arriveMeters then
            waypointArrivedSignature = sig
            sendNavigationVoice(nav.VoiceText or 'You have arrived at your waypoint.')
            if nav.ArrivalNotify ~= false then notify('~b~Navigation:~s~ You have arrived at your waypoint.') end
        end
    else
        lastWaypointSignature = nil
        waypointArrivedSignature = nil
    end

    handleGpsGuidance(veh, state)

    if controllerOnly then
        SendNUIMessage({ action = 'state', state = state })
    else
        sendUi({ action = 'state', state = state })
    end
end

CreateThread(function()
    if Config.PhysicalScreen and Config.PhysicalScreen.enabled then ensureDui() end
    while true do
        local sleep = 500
        if Config.PhysicalScreen.enabled then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and DoesEntityExist(veh) then
                sleep = 0
                ensureScreenProp(veh)
                local visible = true
                if Config.PhysicalScreen.firstPersonOnly and not isFirstPersonVehicleCam() then visible = false end
                if screenProp and DoesEntityExist(screenProp) and Config.PhysicalScreen.propVisibleOnlyFirstPerson then
                    SetEntityVisible(screenProp, visible, false)
                end
                if visible then
                    drawDashboardScreen(veh)
                end
            else
                deleteScreenProp()
                sleep = 500
            end
        end
        Wait(sleep)
    end
end)

CreateThread(function()
    while true do
        local sleep = 650
        local veh = getControlVehicle()
        if uiOpen or (Config.PhysicalScreen.enabled and veh ~= 0) or rearCamActive then
            sleep = 350
            pushState(veh ~= 0 and veh or currentVehicle, not Config.PhysicalScreen.enabled)
        end
        Wait(sleep)
    end
end)


CreateThread(function()
    while true do
        Wait((Config.Contacts and Config.Contacts.refreshMs) or 12000)
        if uiOpen and Config.Contacts and Config.Contacts.enabled ~= false then
            TriggerServerEvent('RD_CarRadio:server:requestContacts')
        end
    end
end)

local function canControlVehicle(veh)
    if not veh or veh == 0 then return false end
    if Config.DriverOnly and GetPedInVehicleSeat(veh, -1) ~= PlayerPedId() then
        return false
    end
    return true
end

local function openController(page)
    local veh = getControlVehicle()
    if Config.RequireInsideVehicleToOpen and veh == 0 then
        notify('~r~Duhet te jesh ulur ne makine per ta hapur CarRadio.')
        return
    end
    if veh ~= 0 and Config.DriverOnly and GetPedInVehicleSeat(veh, -1) ~= PlayerPedId() then
        notify('~r~Vetem shoferi mund ta kontrolloje.')
        return
    end

    currentVehicle = veh
    currentNetId = veh ~= 0 and VehToNet(veh) or nil
    if currentNetId then SetNetworkIdExistsOnAllMachines(currentNetId, true) end
    uiOpen = true
    currentPage = page or currentPage or Config.Controller.startPage or 'home'
    SetNuiFocus(true, true)
    nuiKeepInput(true)
    SendNUIMessage({ action = 'open', page = currentPage, apps = Config.Apps, tablet = Config.TabletUI or {}, mapStyle = Config.Map and Config.Map.Style or 'dark' })
    sendDui({ action = 'setPage', page = currentPage })
    pushState(veh, false)
    TriggerServerEvent('RD_CarRadio:server:requestContacts')
end

local function closeController()
    uiOpen = false
    SetNuiFocus(false, false)
    nuiKeepInput(false)
    SendNUIMessage({ action = 'close' })
end

local function hardReleaseInput(ms)
    ms = tonumber(ms) or (Config.HardReleaseInputMs or 2200)
    local untilTime = GetGameTimer() + ms
    SetNuiFocus(false, false)
    nuiKeepInput(false)
    if SetPlayerControl then SetPlayerControl(PlayerId(), true, 0) end
    CreateThread(function()
        while GetGameTimer() < untilTime do
            SetNuiFocus(false, false)
            nuiKeepInput(false)
            if SetPlayerControl then SetPlayerControl(PlayerId(), true, 0) end
            Wait(0)
        end
    end)
end

RegisterCommand(Config.Command, function()
    if uiOpen then closeController() else openController() end
end)
RegisterKeyMapping(Config.Command, 'RD Car Radio / Complete Car UI', 'keyboard', Config.Keybind)

RegisterCommand('carunbug', function()
    requestVehicleExit(false)
end)
RegisterCommand('rdcar_exit', function()
    requestVehicleExit(false)
end)
RegisterCommand('rdcar_forceexit', function()
    requestVehicleExit(true)
end)

stopRearCamera = function()
    if not rearCamActive then return end
    rearCamActive = false
    RenderScriptCams(false, true, 450, true, true)
    if rearCam then DestroyCam(rearCam, false) end
    rearCam = nil
    rearCamVehicle = 0
    SendNUIMessage({ action = 'cameraClose' })
    sendDui({ action = 'setPage', page = currentPage or 'home' })
end

local function unlockForPlayerExit(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return end
    local playerId = PlayerId()
    if SetVehicleDoorsLockedForPlayer then SetVehicleDoorsLockedForPlayer(veh, playerId, false) end
end

local function releaseVehicleLocksForExit(veh)
    if not veh or veh == 0 or not DoesEntityExist(veh) then return false end
    local wasLocked = GetVehicleDoorLockStatus(veh) >= 2
    unlockForPlayerExit(veh)
    -- GTA lock status 2 mund ta mbaje ped-in brenda. Per dalje e bej temporary unlocked.
    if Config.SafeExitAutoUnlock ~= false then
        SetVehicleDoorsLocked(veh, 1)
        if SetVehicleDoorsLockedForPlayer then SetVehicleDoorsLockedForPlayer(veh, PlayerId(), false) end
    end
    return wasLocked
end

local function teleportOutIfStillTrapped(ped, veh, force)
    if not force and Config.SafeExitTeleportFallback == false then return end
    if not ped or ped == 0 or not veh or veh == 0 or not DoesEntityExist(veh) then return end
    if not IsPedInVehicle(ped, veh, false) then return end

    -- Vetem fallback manual/opsional. Default eshte OFF qe dalja te mos duket keq.
    local sideX = -1.75
    if GetPedInVehicleSeat(veh, -1) ~= ped then sideX = 1.75 end
    local out = GetOffsetFromEntityInWorldCoords(veh, sideX, -0.25, 0.05)
    ClearPedTasksImmediately(ped)
    SetEntityCoordsNoOffset(ped, out.x, out.y, out.z, false, false, false)
    SetEntityHeading(ped, GetEntityHeading(veh) + (sideX < 0 and 270.0 or 90.0))
    ClearPedTasksImmediately(ped)
end

requestVehicleExit = function(force)
    local now = GetGameTimer()
    if now - lastVehicleExitAt < 350 then return end
    lastVehicleExitAt = now
    forcedExitUntil = now + 2200

    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if (not veh or veh == 0) and currentVehicle and currentVehicle ~= 0 and DoesEntityExist(currentVehicle) then
        veh = currentVehicle
    end

    if uiOpen then closeController() end
    if rearCamActive then stopRearCamera() end
    SetNuiFocus(false, false)
    nuiKeepInput(false)
    if SetPlayerControl then SetPlayerControl(PlayerId(), true, 0) end

    if veh and veh ~= 0 and DoesEntityExist(veh) then
        local wasLocked = releaseVehicleLocksForExit(veh)
        ClearPedSecondaryTask(ped)
        TaskLeaveVehicle(ped, veh, 0) -- V5.2: dalje normale me animacion dere, jo warp

        CreateThread(function()
            local retryMs = tonumber(Config.SafeExitRetryMs) or 1800
            Wait(retryMs)
            if DoesEntityExist(veh) and IsPedInVehicle(PlayerPedId(), veh, false) then
                releaseVehicleLocksForExit(veh)
                TaskLeaveVehicle(PlayerPedId(), veh, 0)
            end

            local fallbackMs = tonumber(Config.SafeExitFallbackDelayMs) or 5200
            Wait(math.max(0, fallbackMs - retryMs))
            teleportOutIfStillTrapped(PlayerPedId(), veh, force == true)

            if wasLocked and Config.SafeExitRelockAfterMs and Config.SafeExitRelockAfterMs > 0 then
                Wait(Config.SafeExitRelockAfterMs)
                if veh and DoesEntityExist(veh) and not IsPedInVehicle(PlayerPedId(), veh, false) then
                    SetVehicleDoorsLocked(veh, 2)
                end
            end
        end)
    end
end

local function startRearCamera(veh)
    if not Config.RearCamera.enabled then notify('~r~Rear camera eshte off ne config.') return end
    veh = veh or getControlVehicle()
    if veh == 0 or not DoesEntityExist(veh) then notify('~r~Duhet te jesh ne makine.') return end

    closeController()
    rearCamActive = true
    rearCamVehicle = veh
    if rearCam then DestroyCam(rearCam, false) end
    rearCam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    SetCamFov(rearCam, Config.RearCamera.fov or 72.0)
    RenderScriptCams(true, true, 350, true, true)
    local camState = collectVehicleState(veh)
    local sensor = getParkingSensor(veh)
    SendNUIMessage({ action = 'cameraOpen', state = camState, sensor = sensor })
    sendDui({ action = 'setPage', page = 'camera' })
    sendDui({ action = 'cameraState', state = camState, sensor = sensor })
end

CreateThread(function()
    while true do
        local sleep = 500
        if rearCamActive then
            sleep = 0
            -- Kamera parking eshte fixed: nuk leviz me mouse/right-stick.
            DisableControlAction(0, 1, true)
            DisableControlAction(0, 2, true)
            DisableControlAction(0, 3, true)
            DisableControlAction(0, 4, true)
            DisableControlAction(0, 5, true)
            DisableControlAction(0, 6, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 68, true)
            DisableControlAction(0, 69, true)
            DisableControlAction(0, 70, true)
            DisableControlAction(0, 91, true)
            DisableControlAction(0, 92, true)
            DisableControlAction(0, 106, true)
            if SetGameplayCamRelativeHeading then SetGameplayCamRelativeHeading(0.0) end
            if SetGameplayCamRelativePitch then SetGameplayCamRelativePitch(0.0, 1.0) end

            local veh = rearCamVehicle
            if not veh or veh == 0 or not DoesEntityExist(veh) or not IsPedInVehicle(PlayerPedId(), veh, false) then
                stopRearCamera()
            else
                local coords, lookAt, usesBounds = getRearCameraTransform(veh)
                SetCamCoord(rearCam, coords.x, coords.y, coords.z)
                if lookAt then
                    PointCamAtCoord(rearCam, lookAt.x, lookAt.y, lookAt.z)
                else
                    SetCamRot(rearCam, Config.RearCamera.pitch or -7.0, 0.0, GetEntityHeading(veh) + 180.0, 2)
                end
                SetCamActive(rearCam, true)
                RenderScriptCams(true, false, 0, true, true)
                local camState = collectVehicleState(veh)
                local sensor = getParkingSensor(veh)
                SendNUIMessage({ action = 'cameraState', state = camState, sensor = sensor })
                sendDui({ action = 'cameraState', state = camState, sensor = sensor })
                sendSensorBeep(sensor)
                if IsControlJustPressed(0, 75) or IsDisabledControlJustPressed(0, 75) or IsControlJustPressed(0, 23) or IsDisabledControlJustPressed(0, 23) then
                    requestVehicleExit(false)
                elseif IsControlJustPressed(0, 177) or IsControlJustPressed(0, 200) or IsControlJustPressed(0, 202) or IsControlJustPressed(0, 322) then
                    stopRearCamera()
                end
            end
        end
        Wait(sleep)
    end
end)

-- Safe exit: tableti/camera/door-lock nuk e bllokon me daljen nga makina.
-- F/Exit Vehicle punon edhe kur UI eshte hapur, kur camera eshte ON, ose kur makina eshte locked nga tablet.
CreateThread(function()
    while true do
        local sleep = 350
        local ped = PlayerPedId()
        local inVeh = IsPedInAnyVehicle(ped, false)
        local veh = inVeh and GetVehiclePedIsIn(ped, false) or 0
        local locked = veh ~= 0 and DoesEntityExist(veh) and GetVehicleDoorLockStatus(veh) >= 2

        if inVeh and veh ~= 0 and DoesEntityExist(veh) then
            -- Mos e lejo script-in te te mbaje brenda. Ky nuk e hap makinen per te tjeret, vetem nuk te trap ty.
            if Config.SafeExitNeverTrapPlayer ~= false then unlockForPlayerExit(veh) end
        end

        local monitorNormalDriving = (Config.AlwaysSafeExitMonitor == true and inVeh)
        if uiOpen or rearCamActive or locked or (forcedExitUntil > GetGameTimer()) or monitorNormalDriving then
            sleep = 0

            if uiOpen then
                nuiKeepInput(true)
                -- Blloko levizjen e makines kur tableti eshte hapur, por mos blloko INPUT_VEH_EXIT (75).
                DisableControlAction(0, 59, true)
                DisableControlAction(0, 60, true)
                DisableControlAction(0, 63, true)
                DisableControlAction(0, 64, true)
                DisableControlAction(0, 71, true)
                DisableControlAction(0, 72, true)
                DisableControlAction(0, 76, true)
                DisableControlAction(0, 24, true)
                DisableControlAction(0, 25, true)
                DisableControlAction(0, 68, true)
                DisableControlAction(0, 69, true)
                DisableControlAction(0, 70, true)
            end

            if inVeh and (IsControlJustPressed(0, 75) or IsDisabledControlJustPressed(0, 75) or IsControlJustPressed(0, 23) or IsDisabledControlJustPressed(0, 23)) then
                requestVehicleExit(false)
            elseif uiOpen and (IsControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 177) or IsControlJustPressed(0, 200) or IsDisabledControlJustPressed(0, 200) or IsControlJustPressed(0, 202) or IsDisabledControlJustPressed(0, 202) or IsControlJustPressed(0, 322) or IsDisabledControlJustPressed(0, 322)) then
                closeController()
            end
        end
        Wait(sleep)
    end
end)

local function performVehicleAction(action, value)
    local veh = getControlVehicle()
    if veh == 0 then notify('~r~Nuk je ne makine.') return end
    if not canControlVehicle(veh) and not Config.VehicleControls.allowPassengerControl then notify('~r~Nuk mund ta kontrollosh nga ky seat.') return end

    if action == 'headlights' then
        headlightsOn = not headlightsOn
        SetVehicleLights(veh, headlightsOn and 2 or 0)
        SetVehicleFullbeam(veh, headlightsOn)
    elseif action == 'interior' then
        interiorLights = not interiorLights
        SetVehicleInteriorlight(veh, interiorLights)
    elseif action == 'windows' then
        windowsDown = not windowsDown
        for i = 0, 3 do
            if windowsDown then RollDownWindow(veh, i) else RollUpWindow(veh, i) end
        end
    elseif action == 'trunk' then
        if GetVehicleDoorAngleRatio(veh, 5) > 0.08 then SetVehicleDoorShut(veh, 5, false) else SetVehicleDoorOpen(veh, 5, false, false) end
    elseif action == 'hood' then
        if GetVehicleDoorAngleRatio(veh, 4) > 0.08 then SetVehicleDoorShut(veh, 4, false) else SetVehicleDoorOpen(veh, 4, false, false) end
    elseif action == 'door1' then
        if GetVehicleDoorAngleRatio(veh, 0) > 0.08 then SetVehicleDoorShut(veh, 0, false) else SetVehicleDoorOpen(veh, 0, false, false) end
    elseif action == 'door2' then
        if GetVehicleDoorAngleRatio(veh, 1) > 0.08 then SetVehicleDoorShut(veh, 1, false) else SetVehicleDoorOpen(veh, 1, false, false) end
    elseif action == 'door3' then
        if GetVehicleDoorAngleRatio(veh, 2) > 0.08 then SetVehicleDoorShut(veh, 2, false) else SetVehicleDoorOpen(veh, 2, false, false) end
    elseif action == 'door4' then
        if GetVehicleDoorAngleRatio(veh, 3) > 0.08 then SetVehicleDoorShut(veh, 3, false) else SetVehicleDoorOpen(veh, 3, false, false) end
    elseif action == 'lock' then
        local locked = GetVehicleDoorLockStatus(veh) >= 2
        if locked then
            SetVehicleDoorsLocked(veh, 1)
            if SetVehicleDoorsLockedForAllPlayers then SetVehicleDoorsLockedForAllPlayers(veh, false) end
            notify('~b~Doors:~s~ unlocked')
        else
            SetVehicleDoorsLocked(veh, 2)
            -- V4.9: mos e lejo lock-un nga tableti te trap ped-in brenda.
            unlockForPlayerExit(veh)
            if Config.SafeExitNeverTrapPlayer ~= false and SetVehicleDoorsLockedForPlayer then
                SetVehicleDoorsLockedForPlayer(veh, PlayerId(), false)
            end
            notify('~b~Doors:~s~ locked (safe exit)')
        end
        PlayVehicleDoorCloseSound(veh, 1)
    elseif action == 'engine' then
        SetVehicleEngineOn(veh, not GetIsVehicleEngineRunning(veh), false, true)
    elseif action == 'cruise' then
        cruiseActive = not cruiseActive
        if cruiseActive then
            local speed = math.max(GetEntitySpeed(veh), 1.0)
            SetEntityMaxSpeed(veh, speed)
            notify('~b~Cruise control ON')
        else
            SetEntityMaxSpeed(veh, 999.0)
            notify('~b~Cruise control OFF')
        end
    elseif action == 'seat' then
        local seat = tonumber(value) or -1
        if IsVehicleSeatFree(veh, seat) then TaskWarpPedIntoVehicle(PlayerPedId(), veh, seat) else notify('~r~Seat eshte i zene.') end
    elseif action == 'xenon' then
        local color = tonumber(value) or 1
        ToggleVehicleMod(veh, 22, true)
        if SetVehicleXenonLightsColor then
            SetVehicleXenonLightsColor(veh, color)
        elseif SetVehicleXenonLightsColour then
            SetVehicleXenonLightsColour(veh, color)
        end
        headlightsOn = true
        SetVehicleLights(veh, 2)
    elseif action == 'camera' then
        startRearCamera(veh)
    end

    Wait(50)
    pushState(veh, false)
end

RegisterNUICallback('close', function(_, cb)
    closeController()
    cb({ ok = true })
end)

RegisterNUICallback('forceExit', function(_, cb)
    -- Kur NUI ka fokus, F mund te kape browser-i. Ky callback e nxjerr lojtarin direkt.
    requestVehicleExit(false)
    cb({ ok = true })
end)

RegisterNUICallback('page', function(data, cb)
    currentPage = tostring(data.page or 'home')
    sendDui({ action = 'setPage', page = currentPage })
    pushState(getControlVehicle(), false)
    cb({ ok = true })
end)

RegisterNUICallback('mapZoom', function(data, cb)
    local zoom = tonumber(data and data.zoom) or 1.0
    sendDui({ action = 'mapZoom', zoom = zoom })
    cb({ ok = true })
end)

RegisterNUICallback('gpsTalk', function(data, cb)
    gpsTalkEnabled = data and data.enabled == true
    if Config.Navigation and Config.Navigation.GpsTalkPersist ~= false then SetResourceKvp('rd_carradio_gps_talk', gpsTalkEnabled and '1' or '0') end
    local veh = getControlVehicle()
    if gpsTalkEnabled then
        sendNavigationVoice('GPS voice guidance is on.', false)
        notify('~b~GPS Talk:~s~ ON')
    else
        notify('~b~GPS Talk:~s~ OFF')
    end
    pushState(veh ~= 0 and veh or currentVehicle, false)
    cb({ ok = true, enabled = gpsTalkEnabled })
end)


RegisterNUICallback('gpsVoice', function(data, cb)
    local gender = tostring(data and data.gender or 'female')
    if gender ~= 'male' then gender = 'female' end
    gpsVoiceGender = gender
    SetResourceKvp('rd_carradio_voice_gender', gpsVoiceGender)
    if gpsTalkEnabled then sendNavigationVoice(gender == 'male' and 'Male GPS voice selected.' or 'Female GPS voice selected.', false) end
    pushState(getControlVehicle(), false)
    cb({ ok = true, gender = gpsVoiceGender })
end)



RegisterNetEvent('RD_CarRadio:client:dispatchSMS', function(data)
    data = data or {}
    local coords = data.coords
    if not coords then return end
    local x, y, z = tonumber(coords.x), tonumber(coords.y), tonumber(coords.z)
    if not x or not y or not z then return end
    local label = tostring(data.label or 'SMS Dispatch')
    local msg = tostring(data.message or 'Need assistance')
    notify(('~b~%s:~s~ %s'):format(label, msg))
    local blip = AddBlipForCoord(x, y, z)
    SetBlipSprite(blip, tonumber(data.sprite) or 161)
    SetBlipScale(blip, tonumber(data.scale) or 1.05)
    SetBlipColour(blip, tonumber(data.color) or 3)
    SetBlipAsShortRange(blip, false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(label)
    EndTextCommandSetBlipName(blip)
    SetNewWaypoint(x, y)
    CreateThread(function()
        Wait(tonumber(data.duration) or 90000)
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end)
end)

RegisterNUICallback('requestContacts', function(_, cb)
    TriggerServerEvent('RD_CarRadio:server:requestContacts')
    cb({ ok = true })
end)

RegisterNUICallback('contactAction', function(data, cb)
    data = data or {}
    local veh = getControlVehicle()
    local ped = PlayerPedId()
    local coords = veh ~= 0 and GetEntityCoords(veh) or GetEntityCoords(ped)
    local street, crossing, zone = getStreetAndZone(coords)
    data.coords = { x = coords.x, y = coords.y, z = coords.z }
    data.street = street
    data.zone = zone
    if veh ~= 0 and DoesEntityExist(veh) then
        data.vehicle = modelName(veh)
        data.plate = GetVehicleNumberPlateText(veh)
    end
    TriggerServerEvent('RD_CarRadio:server:contactAction', data)
    cb({ ok = true })
end)

RegisterNUICallback('search', function(data, cb)
    searchReq = searchReq + 1
    TriggerServerEvent('RD_CarRadio:server:searchYoutube', searchReq, data.query or '')
    cb({ ok = true })
end)

RegisterNUICallback('play', function(data, cb)
    local veh = getControlVehicle()
    if veh == 0 then cb({ ok = false, error = 'not_in_vehicle' }) return end
    currentVehicle = veh
    currentNetId = VehToNet(veh)
    SetNetworkIdExistsOnAllMachines(currentNetId, true)
    TriggerServerEvent('RD_CarRadio:server:play', currentNetId, data.videoId or data.url, data.title or 'YouTube Music', data.volume or Config.DefaultRadioVolume, data.queue or {}, data.thumb or '', data.channel or '')

    -- V5.2: pas Play, mbyll vetem UI/focus. Nuk bejme warp/hard exit loop,
    -- keshtu F del nga makina normal si GTA/QB-Core.
    if Config.AutoCloseUIOnMusicPlay ~= false then
        closeController()
    else
        SetNuiFocus(false, false)
        nuiKeepInput(false)
    end
    if Config.HardReleaseInputOnMusicPlay == true then
        hardReleaseInput(Config.HardReleaseInputMs or 1200)
    end

    cb({ ok = true, uiClosed = Config.AutoCloseUIOnMusicPlay ~= false })
end)

RegisterNUICallback('volume', function(data, cb)
    if currentNetId then
        TriggerServerEvent('RD_CarRadio:server:setVolume', currentNetId, tonumber(data.volume) or Config.DefaultRadioVolume)
    end
    cb({ ok = true })
end)

RegisterNUICallback('pause', function(_, cb)
    if currentNetId then TriggerServerEvent('RD_CarRadio:server:pause', currentNetId) end
    cb({ ok = true })
end)

RegisterNUICallback('resume', function(_, cb)
    if currentNetId then TriggerServerEvent('RD_CarRadio:server:resume', currentNetId) end
    cb({ ok = true })
end)

RegisterNUICallback('stop', function(_, cb)
    if currentNetId then TriggerServerEvent('RD_CarRadio:server:stop', currentNetId) end
    cb({ ok = true })
end)

RegisterNUICallback('next', function(data, cb)
    local netId = tonumber(data and data.netId) or currentNetId
    if not netId and currentVehicle ~= 0 then netId = VehToNet(currentVehicle) end
    if netId then TriggerServerEvent('RD_CarRadio:server:next', netId) end
    cb({ ok = true })
end)

RegisterNUICallback('vehicleAction', function(data, cb)
    performVehicleAction(tostring(data.action or ''), data.value)
    cb({ ok = true })
end)

RegisterNUICallback('camera', function(_, cb)
    startRearCamera(getControlVehicle())
    cb({ ok = true })
end)


RegisterNetEvent('RD_CarRadio:client:notify', function(msg, ntype)
    notify(msg, ntype)
end)

RegisterNetEvent('RD_CarRadio:client:contactsUpdate', function(list)
    SendNUIMessage({ action = 'contactsUpdate', contacts = list or {} })
end)

RegisterNetEvent('RD_CarRadio:client:searchResult', function(req, ok, msg, results)
    SendNUIMessage({ action = 'searchResult', requestId = req, ok = ok, message = msg, results = results or {} })
end)

RegisterNetEvent('RD_CarRadio:client:play', function(netId, data)
    startSound(tonumber(netId), data)
end)

RegisterNetEvent('RD_CarRadio:client:setVolume', function(netId, volume)
    netId = tonumber(netId)
    if activeRadios[netId] then activeRadios[netId].volume = volume end
    if currentNetId == netId then SendNUIMessage({ action = 'volume', volume = volume }) end
end)

RegisterNetEvent('RD_CarRadio:client:pause', function(netId)
    netId = tonumber(netId)
    if xsoundReady() and exports[Config.XSoundResource]:soundExists(soundName(netId)) then exports[Config.XSoundResource]:Pause(soundName(netId)) end
    if activeRadios[netId] then activeRadios[netId].paused = true end
    sendDui({ action = 'pause' })
    if currentNetId == netId then SendNUIMessage({ action = 'pause' }) end
end)

RegisterNetEvent('RD_CarRadio:client:resume', function(netId)
    netId = tonumber(netId)
    if xsoundReady() and exports[Config.XSoundResource]:soundExists(soundName(netId)) then exports[Config.XSoundResource]:Resume(soundName(netId)) end
    if activeRadios[netId] then activeRadios[netId].paused = false end
    sendDui({ action = 'resume' })
    if currentNetId == netId then SendNUIMessage({ action = 'resume' }) end
end)

RegisterNetEvent('RD_CarRadio:client:stop', function(netId)
    stopSound(tonumber(netId))
end)

RegisterNetEvent('RD_CarRadio:client:syncAll', function(radios)
    for netId, data in pairs(radios or {}) do
        startSound(tonumber(netId), data)
    end
end)

CreateThread(function()
    Wait(2500)
    TriggerServerEvent('RD_CarRadio:server:requestSync')
end)

-- AutoNext fallback timer per client, vetem kur iframe nuk e kap fundin e videos.
CreateThread(function()
    while true do
        Wait(5000)
        for netId, r in pairs(activeRadios) do
            if r and not r.paused and r.startedLocal and (GetGameTimer() - tonumber(r.startedLocal)) >= (Config.TrackFallbackSeconds * 1000) then
                TriggerServerEvent('RD_CarRadio:server:next', netId)
                r.startedLocal = GetGameTimer()
                Wait(1000)
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    stopRearCamera()
    closeController()
    deleteScreenProp()
    if dui then DestroyDui(dui) end
    for netId in pairs(activeRadios) do stopSound(netId) end
end)
