local radios = {}

local function tryQBCoreJob(src)
    if GetResourceState('qb-core') ~= 'started' then return nil end
    local okqb, QBCore = pcall(function() return exports['qb-core']:GetCoreObject() end)
    if okqb and QBCore and QBCore.Functions and QBCore.Functions.GetPlayer then
        local Player = QBCore.Functions.GetPlayer(src)
        local job = Player and Player.PlayerData and Player.PlayerData.job
        if job and job.name then return string.lower(tostring(job.name)) end
    end
    return nil
end

local function tryESXJob(src)
    if GetResourceState('es_extended') ~= 'started' then return nil end
    local ok, ESX = pcall(function() return exports['es_extended']:getSharedObject() end)
    if ok and ESX and ESX.GetPlayerFromId then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer and xPlayer.getJob then
            local j = xPlayer.getJob()
            return j and j.name and string.lower(tostring(j.name)) or nil
        elseif xPlayer and xPlayer.job and xPlayer.job.name then
            return string.lower(tostring(xPlayer.job.name))
        end
    end
    return nil
end

local function tryVORPJob(src)
    if GetResourceState('vorp_core') ~= 'started' then return nil end
    local okv, VORPcore = pcall(function() return exports.vorp_core:GetCore() end)
    if okv and VORPcore and VORPcore.getUser then
        local okUser, user = pcall(function() return VORPcore.getUser(src) end)
        if okUser and user then
            local character = nil
            if type(user.getUsedCharacter) == 'function' then
                local okChar, char = pcall(function() return user.getUsedCharacter(src) end)
                character = okChar and char or nil
            elseif type(user.getUsedCharacter) == 'table' then
                character = user.getUsedCharacter
            end
            if type(character) == 'table' and character.job then return string.lower(tostring(character.job)) end
        end
    end
    return nil
end

local function getFrameworkJob(src)
    local fw = string.lower(tostring(Config.Framework or 'auto'))
    if fw == 'qb' or fw == 'qb-core' then return tryQBCoreJob(src) end
    if fw == 'esx' then return tryESXJob(src) end
    if fw == 'vorp' then return tryVORPJob(src) end
    -- auto: QB first for FiveM, then ESX, then VORP fallback
    return tryQBCoreJob(src) or tryESXJob(src) or tryVORPJob(src)
end

local function buildContacts()
    local cfg = Config.Contacts or {}
    local jobs = cfg.jobs or {}
    local counts = {}
    for _, id in ipairs(GetPlayers()) do
        local src = tonumber(id)
        local job = src and getFrameworkJob(src)
        if job then counts[string.lower(job)] = (counts[string.lower(job)] or 0) + 1 end
    end
    local out = {}
    local added = {}
    for _, c in ipairs(jobs) do
        local job = string.lower(tostring(c.name or ''))
        local count = counts[job] or 0
        local key = string.lower(tostring(c.label or job)) .. ':' .. tostring(c.phone or '')
        if count > 0 or c.alwaysShow then
            if not added[key] then
                added[key] = true
                out[#out + 1] = {
                    name = c.label or c.name or 'Contact',
                    job = c.name or '',
                    phone = c.phone or '',
                    initials = c.initials or string.upper(string.sub(c.label or c.name or 'C', 1, 2)),
                    online = count,
                    available = count > 0
                }
            else
                for _, o in ipairs(out) do
                    if (string.lower(tostring(o.name)) .. ':' .. tostring(o.phone or '')) == key then
                        o.online = (o.online or 0) + count
                        o.available = o.online > 0
                        break
                    end
                end
            end
        end
    end
    return out
end



local function clamp(n, min, max)
    n = tonumber(n) or min
    if n < min then return min end
    if n > max then return max end
    return n
end

local function jsonDecode(str)
    local ok, data = pcall(json.decode, str or '{}')
    return ok and data or {}
end

local function extractVideoId(url)
    if not url then return nil end
    url = tostring(url)
    local patterns = {
        'youtu%.be/([%w_-]+)',
        'youtube%.com/watch%?v=([%w_-]+)',
        'youtube%.com/watch%?.-v=([%w_-]+)',
        'music%.youtube%.com/watch%?v=([%w_-]+)',
        'music%.youtube%.com/watch%?.-v=([%w_-]+)',
        'youtube%.com/shorts/([%w_-]+)',
        'youtube%.com/embed/([%w_-]+)',
        '^([%w_-]+)$'
    }
    for _, p in ipairs(patterns) do
        local id = url:match(p)
        if id and #id >= 8 then return id end
    end
    return nil
end

local function urlencode(str)
    str = tostring(str or ''):gsub('\n', ' ')
    str = str:gsub('([^%w%-_%.~ ])', function(c)
        return string.format('%%%02X', string.byte(c))
    end)
    return str:gsub(' ', '+')
end

local function youtubeSearch(query, relatedVideoId, cb)
    if not Config.YouTubeApiKey or Config.YouTubeApiKey == '' then
        cb(false, 'Mungon YouTubeApiKey ne config.lua. Link YouTube mund ta besh paste direkt edhe pa key.', {})
        return
    end

    local url
    if relatedVideoId and relatedVideoId ~= '' then
        url = ('https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=%s&relatedToVideoId=%s&key=%s')
            :format(Config.MaxSearchResults, urlencode(relatedVideoId), Config.YouTubeApiKey)
    else
        url = ('https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=%s&q=%s&key=%s')
            :format(Config.MaxSearchResults, urlencode(query), Config.YouTubeApiKey)
    end

    PerformHttpRequest(url, function(status, body)
        if status ~= 200 then
            cb(false, 'YouTube API HTTP '..tostring(status), {})
            return
        end

        local data = jsonDecode(body)
        local results = {}
        for _, item in ipairs(data.items or {}) do
            local vid = item.id and item.id.videoId
            local sn = item.snippet or {}
            local thumb = ''
            if sn.thumbnails then
                thumb = (sn.thumbnails.medium and sn.thumbnails.medium.url) or (sn.thumbnails.default and sn.thumbnails.default.url) or ''
            end
            if vid then
                results[#results + 1] = {
                    videoId = vid,
                    title = sn.title or 'YouTube Music',
                    channel = sn.channelTitle or 'YouTube',
                    thumb = thumb
                }
            end
        end
        cb(true, 'ok', results)
    end, 'GET')
end

RegisterNetEvent('RD_CarRadio:server:searchYoutube', function(requestId, query)
    local src = source
    query = tostring(query or ''):sub(1, 120)
    if query == '' then
        TriggerClientEvent('RD_CarRadio:client:searchResult', src, requestId, false, 'Shkruaj emrin e kenges/artistit.', {})
        return
    end

    youtubeSearch(query, nil, function(ok, msg, results)
        TriggerClientEvent('RD_CarRadio:client:searchResult', src, requestId, ok, msg, results)
    end)
end)

RegisterNetEvent('RD_CarRadio:server:play', function(netId, videoIdOrUrl, title, volume, queue, thumb, channel)
    netId = tonumber(netId)
    local videoId = extractVideoId(videoIdOrUrl)
    if not netId or not videoId then return end

    local cleanQueue = {}
    if type(queue) == 'table' then
        for _, item in ipairs(queue) do
            local qid = extractVideoId(item.videoId or item.url)
            if qid then
                cleanQueue[#cleanQueue + 1] = {
                    videoId = qid,
                    title = tostring(item.title or 'YouTube Music'):sub(1, 140),
                    channel = tostring(item.channel or 'YouTube'):sub(1, 80),
                    thumb = tostring(item.thumb or ''):sub(1, 250)
                }
            end
        end
    end

    radios[netId] = {
        videoId = videoId,
        title = tostring(title or 'YouTube Music'):sub(1, 140),
        channel = tostring(channel or 'YouTube / RD CarRadio'):sub(1, 80),
        thumb = tostring(thumb or ''):sub(1, 250),
        volume = clamp(volume, 0.0, 1.0),
        queue = cleanQueue,
        lastQuery = tostring(title or Config.AutoNextFallbackQuery):sub(1, 120),
        startedAt = os.time(),
        paused = false
    }

    TriggerClientEvent('RD_CarRadio:client:play', -1, netId, radios[netId])
end)

RegisterNetEvent('RD_CarRadio:server:setVolume', function(netId, volume)
    netId = tonumber(netId)
    if not netId or not radios[netId] then return end
    radios[netId].volume = clamp(volume, 0.0, 1.0)
    TriggerClientEvent('RD_CarRadio:client:setVolume', -1, netId, radios[netId].volume)
end)

RegisterNetEvent('RD_CarRadio:server:pause', function(netId)
    netId = tonumber(netId)
    if not netId or not radios[netId] then return end
    radios[netId].paused = true
    TriggerClientEvent('RD_CarRadio:client:pause', -1, netId)
end)

RegisterNetEvent('RD_CarRadio:server:resume', function(netId)
    netId = tonumber(netId)
    if not netId or not radios[netId] then return end
    radios[netId].paused = false
    radios[netId].startedAt = os.time()
    TriggerClientEvent('RD_CarRadio:client:resume', -1, netId)
end)

RegisterNetEvent('RD_CarRadio:server:stop', function(netId)
    netId = tonumber(netId)
    if not netId then return end
    radios[netId] = nil
    TriggerClientEvent('RD_CarRadio:client:stop', -1, netId)
end)

RegisterNetEvent('RD_CarRadio:server:next', function(netId)
    netId = tonumber(netId)
    if not netId or not radios[netId] then return end

    local r = radios[netId]
    local item = type(r.queue) == 'table' and table.remove(r.queue, 1) or nil

    local function playItem(it)
        if not it then return end
        local nextId = extractVideoId(it.videoId or it.url)
        if not nextId then return end
        r.videoId = nextId
        r.title = tostring(it.title or 'YouTube Music'):sub(1, 140)
        r.channel = tostring(it.channel or r.channel or 'YouTube'):sub(1, 80)
        r.thumb = tostring(it.thumb or r.thumb or ''):sub(1, 250)
        r.startedAt = os.time()
        r.paused = false
        radios[netId] = r
        TriggerClientEvent('RD_CarRadio:client:play', -1, netId, r)
    end

    if item then
        playItem(item)
        return
    end

    if Config.AutoNext then
        youtubeSearch(r.lastQuery or Config.AutoNextFallbackQuery, r.videoId, function(ok, _, results)
            if ok and results and #results > 0 then
                r.queue = results
                playItem(table.remove(r.queue, 1))
            end
        end)
    end
end)


RegisterNetEvent('RD_CarRadio:server:requestContacts', function()
    local src = source
    if Config.Contacts and Config.Contacts.enabled == false then
        TriggerClientEvent('RD_CarRadio:client:contactsUpdate', src, {})
        return
    end
    TriggerClientEvent('RD_CarRadio:client:contactsUpdate', src, buildContacts())
end)

local function getDispatchTargetsForJob(job)
    local cfg = Config.DispatchSMS or {}
    local map = cfg.jobs or {}
    local entry = map[job] or map[string.lower(tostring(job or ''))]
    local out = {}
    if entry and type(entry.targets) == 'table' then
        for _, j in ipairs(entry.targets) do out[string.lower(tostring(j))] = true end
    else
        out[string.lower(tostring(job or ''))] = true
    end
    return out, entry or {}
end

local function countTable(t)
    local n = 0
    for _ in pairs(t or {}) do n = n + 1 end
    return n
end


local function notifyClient(src, msg, ntype)
    TriggerClientEvent('RD_CarRadio:client:notify', src, tostring(msg or ''), ntype or 'primary')
end

RegisterNetEvent('RD_CarRadio:server:contactAction', function(data)
    local src = source
    if Config.DispatchSMS and Config.DispatchSMS.enabled == false then return end
    data = type(data) == 'table' and data or {}
    local job = string.lower(tostring(data.job or 'police'))
    local targets, entry = getDispatchTargetsForJob(job)
    local coords = data.coords or {}
    local msg = tostring(data.message or '')
    if msg == '' then msg = (Config.DispatchSMS and Config.DispatchSMS.defaultMessage) or 'Need assistance at my GPS position.' end
    msg = msg:sub(1, 180)
    local label = tostring(entry.label or data.name or '911 SMS'):sub(1, 45)
    local street = tostring(data.street or 'Unknown street')
    local zone = tostring(data.zone or '')
    local vehicle = tostring(data.vehicle or 'Vehicle')
    local plate = tostring(data.plate or 'RD')
    local caller = GetPlayerName(src) or ('ID ' .. tostring(src))
    local sent = 0
    for _, id in ipairs(GetPlayers()) do
        local pid = tonumber(id)
        local pjob = pid and getFrameworkJob(pid)
        if pjob and targets[string.lower(tostring(pjob))] then
            sent = sent + 1
            TriggerClientEvent('RD_CarRadio:client:dispatchSMS', pid, {
                label = label,
                message = msg,
                caller = caller,
                street = street,
                zone = zone,
                vehicle = vehicle,
                plate = plate,
                coords = coords,
                duration = (Config.DispatchSMS and Config.DispatchSMS.blipDurationMs) or 90000,
                sprite = (Config.DispatchSMS and Config.DispatchSMS.blipSprite) or 161,
                scale = (Config.DispatchSMS and Config.DispatchSMS.blipScale) or 1.05,
                color = job == 'police' and 3 or (job == 'mechanic' and 5 or 1)
            })
            notifyClient(pid, ('%s | %s %s | %s | %s'):format(msg, vehicle, plate, street, zone), job == 'police' and 'error' or 'primary')
            TriggerClientEvent('chat:addMessage', pid, { args = { label, ('%s | %s %s | %s | %s'):format(msg, vehicle, plate, street, zone) } })
        end
    end
    notifyClient(src, ('SMS sent to %s (%s online). Blip attached.'):format(label, sent), sent > 0 and 'success' or 'error')
    TriggerClientEvent('chat:addMessage', src, { args = { 'RD CarRadio', ('SMS sent to %s (%s online). Blip attached.'):format(label, sent) } })
end)

RegisterNetEvent('RD_CarRadio:server:requestSync', function()
    TriggerClientEvent('RD_CarRadio:client:syncAll', source, radios)
end)

AddEventHandler('playerJoining', function()
    TriggerClientEvent('RD_CarRadio:client:syncAll', source, radios)
end)

CreateThread(function()
    Wait(1000)
    print(('[RD_carradio] V5.2 loaded | framework=%s | qb-core=%s | xsound=%s'):format(tostring(Config.Framework or 'auto'), GetResourceState('qb-core'), GetResourceState(Config.XSoundResource or 'xsound')))
end)
