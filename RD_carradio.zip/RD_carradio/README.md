# RD_carradio V5.2

Stable audio-only car radio / tablet UI for FiveM.

## Install
```cfg
ensure xsound
ensure RD_carradio
```

## Framework
In `config.lua`:
```lua
Config.Framework = 'auto' -- auto / qb / esx / standalone
```
For QB-Core set:
```lua
Config.Framework = 'qb'
```

## Main fixes in V5.2
- Natural GTA/QB vehicle exit animation. No forced warp by default.
- Music is audio-only with xSound; no YouTube iframe video glitch.
- After Play URL, UI focus closes cleanly so F exits vehicle normally.
- `/rdcar_forceexit` exists only as emergency manual fallback.
- QB-Core job detection and QBCore notifications.
- Contacts send SMS/dispatch blip to online job players, not phone call.

## Useful config
```lua
Config.ServerName = 'EAGLE CITY RP'
Config.SafeExitTeleportFallback = false
Config.SafeExitInstantWarp = false
Config.AutoCloseUIOnMusicPlay = true
Config.HardReleaseInputOnMusicPlay = false
```
